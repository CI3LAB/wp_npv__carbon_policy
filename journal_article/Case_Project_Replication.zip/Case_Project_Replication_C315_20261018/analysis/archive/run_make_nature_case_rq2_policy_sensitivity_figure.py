"""Create the case-study RQ2 policy-sensitivity figure.

The script follows the figure contract in
planning/nature_figure_contract_case_rq2_policy_sensitivity.md. It reads the
processed case-study RQ2 policy-sensitivity tables and exports a
publication-ready figure bundle plus the exact plotting data used in each
panel.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(r"C:\files\Documents\.codex\work_package_tax_carbon_research")
TABLE_DIR = PROJECT_ROOT / "R1/manuscript_component/carbon_case_update/data"
MAIN_CSV = TABLE_DIR / "case_rq2_policy_response.csv"
MAIN_EFFECTS_CSV = MAIN_CSV
STRUCTURE_CSV = MAIN_CSV
OUTPUT_DIR = PROJECT_ROOT / "R1/manuscript_component/carbon_case_update/figures"
FIGURE_STEM = OUTPUT_DIR / "fig_large_case_rq2_policy_sensitivity"
PLOT_DATA_CSV = OUTPUT_DIR / "fig_large_case_rq2_policy_sensitivity_plot_data.csv"
CAPTION_MD = OUTPUT_DIR / "fig_large_case_rq2_policy_sensitivity_caption.md"
QA_MD = OUTPUT_DIR / "fig_large_case_rq2_policy_sensitivity_qa.md"

SUBSIDY_PANEL = "Subsidy sensitivity (tax fixed at 0.5)"
TAX_PANEL = "Tax sensitivity (subsidy fixed at 0.5)"
PROFILE_ORDER = [SUBSIDY_PANEL, TAX_PANEL]
PROFILE_LABELS = {
    SUBSIDY_PANEL: "Subsidy varied, tax=0.5",
    TAX_PANEL: "Tax varied, subsidy=0.5",
}
PROFILE_KEYS = {
    SUBSIDY_PANEL: "subsidy_varied",
    TAX_PANEL: "tax_varied",
}
RATES = [0.0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0]
RATE_LABELS = ["0", "0.2", "0.4", "0.5", "0.6", "0.8", "1.0"]

NUMERIC_COLUMNS = [
    "Focal rate",
    "Final packages",
    "Avg. package size",
    "STD package size",
    "Mitigation value",
    "Mitigation ratio (%)",
    "Final value",
]
REQUIRED_COLUMNS = NUMERIC_COLUMNS + ["Panel", "Stop"]
ENDPOINT_METRICS = [
    ("Final packages", "Final packages", "packages", "structure"),
    ("Avg. package size", "Avg. package size", "tasks/package", "structure"),
    ("Pkg. size dispersion", "STD package size", "tasks", "structure"),
    ("Mitigation value", "Mitigation value", "objective units", "finance"),
    ("Final value", "Final value", "objective units", "finance"),
]
COLORS = {
    "subsidy": "#2A9D8F",
    "tax": "#C44E52",
    "structure": "#4C78A8",
    "positive": "#2A9D8F",
    "negative": "#C44E52",
    "grid": "#E5E7EB",
    "text": "#111827",
    "muted": "#6B7280",
    "light_teal": "#DDF3EF",
    "light_red": "#F6E0E1",
}


def normalize_stop(value: object) -> str:
    text = str(value).strip().lower().replace("_", " ")
    if text == "iteration cap":
        return "iteration cap"
    if text == "converged":
        return "converged"
    raise ValueError(f"Unexpected stop status: {value!r}")


def format_rate(value: float) -> str:
    for rate, label in zip(RATES, RATE_LABELS):
        if abs(value - rate) < 1e-12:
            return label
    return f"{value:g}"


def normalize_large_case_table(frame: pd.DataFrame) -> pd.DataFrame:
    panel_map = {
        "Green subsidy": SUBSIDY_PANEL,
        "Carbon tax": TAX_PANEL,
    }
    return frame.rename(
        columns={
            "policy_dimension": "Panel",
            "focal_rate": "Focal rate",
            "final_packages": "Final packages",
            "mean_package_size": "Avg. package size",
            "STD_package_size": "STD package size",
            "mitigation_value": "Mitigation value",
            "mitigation_ratio_pct": "Mitigation ratio (%)",
            "final_value": "Final value",
            "stopped_by": "Stop",
        }
    ).assign(Panel=lambda data: data["Panel"].map(panel_map))


def load_and_validate() -> pd.DataFrame:
    main = normalize_large_case_table(pd.read_csv(MAIN_CSV))
    effects = normalize_large_case_table(pd.read_csv(MAIN_EFFECTS_CSV))
    structure = normalize_large_case_table(pd.read_csv(STRUCTURE_CSV))

    missing = set(REQUIRED_COLUMNS).difference(main.columns)
    if missing:
        raise ValueError(f"Missing required main-table columns: {sorted(missing)}")

    for column in NUMERIC_COLUMNS:
        main[column] = pd.to_numeric(main[column], errors="raise")
    main["Stop"] = main["Stop"].map(normalize_stop)

    if len(main) != 14:
        raise ValueError(f"Expected 14 policy rows, found {len(main)}")
    profiles = main["Panel"].drop_duplicates().tolist()
    if set(profiles) != set(PROFILE_ORDER):
        raise ValueError(f"Unexpected sensitivity profiles: {profiles}")

    main["profile_order"] = main["Panel"].map({name: idx for idx, name in enumerate(PROFILE_ORDER)})
    main = main.sort_values(["profile_order", "Focal rate"]).drop(columns="profile_order").reset_index(drop=True)

    expected_rates = [round(value, 10) for value in RATES]
    for profile in PROFILE_ORDER:
        observed = main.loc[main["Panel"] == profile, "Focal rate"].round(10).tolist()
        if observed != expected_rates:
            raise ValueError(f"Unexpected focal rates for {profile}: {observed}")

    subsidy_base = main[(main["Panel"] == SUBSIDY_PANEL) & np.isclose(main["Focal rate"], 0.5)].iloc[0]
    tax_base = main[(main["Panel"] == TAX_PANEL) & np.isclose(main["Focal rate"], 0.5)].iloc[0]
    base_checks = [
        "Final packages",
        "Avg. package size",
        "STD package size",
        "Mitigation value",
        "Final value",
    ]
    for column in base_checks:
        if not np.isclose(float(subsidy_base[column]), float(tax_base[column]), atol=1e-6):
            raise ValueError(f"Base-case mismatch in column {column}")

    expected_base = {'Final packages': 777.0, 'Avg. package size': 1.202059202059202, 'STD package size': 0.7027896413549037, 'Mitigation value': 12105.53307850883, 'Final value': -89723.03928002933}
    for column, expected in expected_base.items():
        if not np.isclose(float(subsidy_base[column]), expected, atol=1e-6):
            raise ValueError(f"Unexpected base-case value for {column}")

    validate_supporting_table(main, effects, ["Final packages", "Avg. package size", "STD package size", "Mitigation value", "Final value", "Stop"])
    validate_supporting_table(main, structure, ["Final packages", "Avg. package size", "STD package size", "Stop"])

    main = add_plot_helpers(main)
    return main


def validate_supporting_table(main: pd.DataFrame, support: pd.DataFrame, columns: list[str]) -> None:
    missing = {"Panel", "Focal rate"}.union(columns).difference(support.columns)
    if missing:
        raise ValueError(f"Missing supporting-table columns: {sorted(missing)}")

    support = support.copy()
    for column in ["Focal rate"] + [c for c in columns if c != "Stop"]:
        support[column] = pd.to_numeric(support[column], errors="raise")
    if "Stop" in columns:
        support["Stop"] = support["Stop"].map(normalize_stop)

    merged = main[["Panel", "Focal rate"] + columns].merge(
        support[["Panel", "Focal rate"] + columns],
        on=["Panel", "Focal rate"],
        suffixes=("_main", "_support"),
        how="left",
        validate="one_to_one",
    )
    if merged.isna().any(axis=None):
        raise ValueError("Supporting table does not cover every main-table row")
    for column in columns:
        left = merged[f"{column}_main"]
        right = merged[f"{column}_support"]
        if column == "Stop":
            if not (left == right).all():
                raise ValueError("Stop statuses differ between main and supporting tables")
        elif not np.allclose(left.to_numpy(dtype=float), right.to_numpy(dtype=float), atol=1e-6):
            raise ValueError(f"Column {column} differs between main and supporting tables")


def add_plot_helpers(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["profile_key"] = df["Panel"].map(PROFILE_KEYS)
    df["profile_label"] = df["Panel"].map(PROFILE_LABELS)
    df["rate_label"] = df["Focal rate"].map(format_rate)
    df["final_value_k"] = df["Final value"] / 1000.0
    df["mitigation_value_k"] = df["Mitigation value"] / 1000.0
    min_mit = float(df["Mitigation value"].min())
    max_mit = float(df["Mitigation value"].max())
    df["mitigation_marker_area"] = 45 + 195 * (df["Mitigation value"] - min_mit) / (max_mit - min_mit)
    df["marker_status"] = np.where(df["Stop"].eq("iteration cap"), "iteration_cap", "converged")
    for profile in PROFILE_ORDER:
        base = float(df.loc[(df["Panel"] == profile) & np.isclose(df["Focal rate"], 0.0), "Mitigation value"].iloc[0])
        mask = df["Panel"] == profile
        df.loc[mask, "mitigation_delta_from_rate0"] = df.loc[mask, "Mitigation value"] - base
        df.loc[mask, "mitigation_delta_pct_from_rate0"] = 100 * (df.loc[mask, "Mitigation value"] - base) / abs(base)
    return df


def build_endpoint_data(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for profile in PROFILE_ORDER:
        profile_df = df[df["Panel"] == profile]
        start = profile_df[np.isclose(profile_df["Focal rate"], 0.0)].iloc[0]
        end = profile_df[np.isclose(profile_df["Focal rate"], 1.0)].iloc[0]
        for metric_label, column, unit, family in ENDPOINT_METRICS:
            start_value = float(start[column])
            end_value = float(end[column])
            change = end_value - start_value
            pct = 100 * change / abs(start_value) if not np.isclose(start_value, 0.0) else np.nan
            clipped_pct = float(np.clip(pct, -105, 80))
            rows.append(
                {
                    "panel": "c",
                    "profile": PROFILE_KEYS[profile],
                    "profile_label": PROFILE_LABELS[profile],
                    "metric": metric_label,
                    "source_column": column,
                    "unit": unit,
                    "response_family": family,
                    "rate0_value": start_value,
                    "rate1_value": end_value,
                    "endpoint_change": change,
                    "endpoint_change_pct": pct,
                    "endpoint_change_pct_display": clipped_pct,
                    "display_clipped": not np.isclose(pct, clipped_pct),
                }
            )
    return pd.DataFrame(rows)


def build_plot_data(df: pd.DataFrame, endpoint_df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for _, source_row in df.iterrows():
        rows.append(
            {
                "panel": "a",
                "metric": "policy_trajectory_map",
                "profile": source_row["profile_key"],
                "profile_label": source_row["profile_label"],
                "focal_rate": source_row["Focal rate"],
                "focal_rate_label": source_row["rate_label"],
                "avg_package_size": source_row["Avg. package size"],
                "final_value": source_row["Final value"],
                "final_value_k": source_row["final_value_k"],
                "mitigation_value": source_row["Mitigation value"],
                "mitigation_marker_area": source_row["mitigation_marker_area"],
                "stop": source_row["Stop"],
                "marker_status": source_row["marker_status"],
                "value_raw": source_row["Final value"],
                "value_display": source_row["final_value_k"],
            }
        )
        rows.append(
            {
                "panel": "b",
                "metric": "mitigation_response_lane",
                "profile": source_row["profile_key"],
                "profile_label": source_row["profile_label"],
                "focal_rate": source_row["Focal rate"],
                "focal_rate_label": source_row["rate_label"],
                "mitigation_value": source_row["Mitigation value"],
                "mitigation_value_k": source_row["mitigation_value_k"],
                "mitigation_delta_from_rate0": source_row["mitigation_delta_from_rate0"],
                "mitigation_delta_pct_from_rate0": source_row["mitigation_delta_pct_from_rate0"],
                "stop": source_row["Stop"],
                "marker_status": source_row["marker_status"],
                "value_raw": source_row["Mitigation value"],
                "value_display": source_row["mitigation_value_k"],
            }
        )
    for _, row in endpoint_df.iterrows():
        rows.append(
            {
                "panel": "c",
                "metric": row["metric"],
                "profile": row["profile"],
                "profile_label": row["profile_label"],
                "source_column": row["source_column"],
                "unit": row["unit"],
                "response_family": row["response_family"],
                "rate0_value": row["rate0_value"],
                "rate1_value": row["rate1_value"],
                "endpoint_change": row["endpoint_change"],
                "endpoint_change_pct": row["endpoint_change_pct"],
                "endpoint_change_pct_display": row["endpoint_change_pct_display"],
                "display_clipped": row["display_clipped"],
                "value_raw": row["endpoint_change_pct"],
                "value_display": row["endpoint_change_pct_display"],
            }
        )
    return pd.DataFrame(rows)


def money_k_tick(value: float, _pos: object | None = None) -> str:
    if abs(value) < 1e-9:
        return "0"
    return f"{value:.0f}k"


def mitigation_k_tick(value: float, _pos: object | None = None) -> str:
    return f"{value:.1f}k"


def style_axis(ax: plt.Axes, grid_axis: str = "y") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#9CA3AF")
    ax.spines["bottom"].set_color("#9CA3AF")
    ax.tick_params(axis="both", colors=COLORS["text"], labelsize=6.4, width=0.7, length=3)
    ax.set_axisbelow(True)
    if grid_axis == "y":
        ax.yaxis.grid(True, color=COLORS["grid"], linewidth=0.6)
        ax.xaxis.grid(False)
    elif grid_axis == "x":
        ax.xaxis.grid(True, color=COLORS["grid"], linewidth=0.6)
        ax.yaxis.grid(False)


def add_panel_label(ax: plt.Axes, label: str, x: float = -0.06, y: float = 1.08) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8,
        fontweight="bold",
        color=COLORS["text"],
    )


def profile_color(profile: str) -> str:
    return COLORS["subsidy"] if profile == SUBSIDY_PANEL else COLORS["tax"]


def plot_marker(ax: plt.Axes, row: pd.Series, x: float, y: float, size: float, color: str, zorder: int = 4) -> None:
    if row["Stop"] == "iteration cap":
        ax.scatter([x], [y], s=size, facecolor="white", edgecolor=color, linewidth=1.15, zorder=zorder)
    else:
        ax.scatter([x], [y], s=size, facecolor=color, edgecolor="white", linewidth=0.7, zorder=zorder)


def plot_policy_trajectory(ax: plt.Axes, df: pd.DataFrame) -> None:
    for profile in PROFILE_ORDER:
        sub = df[df["Panel"] == profile].sort_values("Focal rate")
        color = profile_color(profile)
        x = sub["Avg. package size"].to_numpy(dtype=float)
        y = sub["final_value_k"].to_numpy(dtype=float)
        ax.plot(x, y, color=color, linewidth=1.25, alpha=0.78, zorder=2)
        for idx in range(len(sub) - 1):
            ax.annotate(
                "",
                xy=(x[idx + 1], y[idx + 1]),
                xytext=(x[idx], y[idx]),
                arrowprops={"arrowstyle": "->", "lw": 0.75, "color": color, "alpha": 0.55, "shrinkA": 6, "shrinkB": 6},
                zorder=2,
            )
        for _, row in sub.iterrows():
            plot_marker(
                ax,
                row,
                float(row["Avg. package size"]),
                float(row["final_value_k"]),
                float(row["mitigation_marker_area"]),
                color,
                zorder=5,
            )
        start = sub.iloc[0]
        end = sub.iloc[-1]
        ax.text(start["Avg. package size"] + 0.025, start["final_value_k"] + 1.2, "rate 0", fontsize=5.8, color=color, ha="left")
        ax.text(end["Avg. package size"] - 0.03, end["final_value_k"] + (1.9 if profile == SUBSIDY_PANEL else -2.7), "rate 1", fontsize=5.8, color=color, ha="right")

    ax.axhline(0, color="#9CA3AF", linewidth=0.7, linestyle=(0, (2, 2)))
    ax.set_title("Policy trajectory: package scale vs. final value", loc="left", fontsize=8, pad=7)
    ax.set_xlabel("Average package size")
    ax.set_ylabel("Final project value")
    x_all = df["Avg. package size"].to_numpy(dtype=float)
    y_all = df["final_value_k"].to_numpy(dtype=float)
    x_pad = max(0.08, 0.08 * (x_all.max() - x_all.min()))
    y_pad = max(4.0, 0.08 * (y_all.max() - y_all.min()))
    ax.set_xlim(x_all.min() - x_pad, x_all.max() + x_pad)
    ax.set_ylim(y_all.min() - y_pad, y_all.max() + y_pad)
    ax.yaxis.set_major_formatter(FuncFormatter(money_k_tick))
    style_axis(ax)
    ax.text(
        0.02,
        0.94,
        "marker area: mitigation value",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=5.8,
        color=COLORS["muted"],
    )
    add_panel_label(ax, "a", x=-0.04, y=1.08)


def plot_mitigation_lane(ax: plt.Axes, df: pd.DataFrame) -> None:
    for profile in PROFILE_ORDER:
        sub = df[df["Panel"] == profile].sort_values("Focal rate")
        color = profile_color(profile)
        x = sub["Focal rate"].to_numpy(dtype=float)
        y = sub["mitigation_value_k"].to_numpy(dtype=float)
        ax.fill_between(x, 0, y, color=color, alpha=0.17, linewidth=0)
        ax.plot(x, y, color=color, linewidth=1.3, alpha=0.95)
        for _, row in sub.iterrows():
            plot_marker(ax, row, float(row["Focal rate"]), float(row["mitigation_value_k"]), 28, color)
        ax.text(
            x[-1] + 0.025,
            y[-1],
            f"{y[0]:.2f} -> {y[-1]:.2f}k",
            ha="left",
            va="center",
            fontsize=5.8,
            color=color,
        )
    capped = df[(df["Panel"] == TAX_PANEL) & (df["Stop"] == "iteration cap")]
    for _, row in capped.iterrows():
        ax.text(row["Focal rate"], row["mitigation_value_k"] + 0.13, "cap", ha="center", va="bottom", fontsize=5.5, color=COLORS["tax"])

    ax.set_title("Incremental mitigation response", loc="left", fontsize=8, pad=7)
    ax.set_xlabel("Focal policy rate")
    ax.set_ylabel("Mitigation value")
    ax.set_xlim(-0.035, 1.20)
    ax.set_ylim(0, df["mitigation_value_k"].max() * 1.18)
    ax.set_xticks(RATES)
    ax.set_xticklabels(RATE_LABELS)
    ax.yaxis.set_major_formatter(FuncFormatter(mitigation_k_tick))
    style_axis(ax)
    add_panel_label(ax, "b", x=-0.10, y=1.08)


def pct_label(value: float, clipped: bool) -> str:
    if abs(value) >= 1000:
        return f"{value:,.0f}%"
    if abs(value) >= 100:
        return f"{value:.0f}%"
    return f"{value:+.1f}%"


def plot_endpoint_matrix(ax: plt.Axes, endpoint_df: pd.DataFrame) -> None:
    metrics = [metric for metric, _column, _unit, _family in ENDPOINT_METRICS]
    y_positions = np.arange(len(metrics))[::-1]
    y_lookup = dict(zip(metrics, y_positions))
    offsets = {"subsidy_varied": 0.11, "tax_varied": -0.11}
    color_lookup = {"subsidy_varied": COLORS["subsidy"], "tax_varied": COLORS["tax"]}
    marker_lookup = {"subsidy_varied": "o", "tax_varied": "D"}

    for metric in metrics:
        ax.hlines(y_lookup[metric], -105, 80, color=COLORS["grid"], linewidth=0.55, zorder=0)
    ax.axvline(0, color="#9CA3AF", linewidth=0.75)
    ax.axvspan(-105, 0, color="#FEF2F2", alpha=0.35, zorder=0)
    ax.axvspan(0, 80, color="#ECFDF5", alpha=0.35, zorder=0)

    for _, row in endpoint_df.iterrows():
        y = y_lookup[row["metric"]] + offsets[row["profile"]]
        x = float(row["endpoint_change_pct_display"])
        color = color_lookup[row["profile"]]
        ax.plot([0, x], [y, y], color=color, linewidth=1.15, alpha=0.82)
        ax.scatter([x], [y], s=34, marker=marker_lookup[row["profile"]], color=color, edgecolor="white", linewidth=0.6, zorder=4)
        if bool(row["display_clipped"]) and x > 0:
            ha = "right"
            label_x = x - 4
        elif bool(row["display_clipped"]) and x < 0:
            ha = "left"
            label_x = x + 3.8
        else:
            ha = "left" if x >= 0 else "right"
            label_x = x + (2.5 if x >= 0 else -2.5)
        ax.text(
            label_x,
            y + (0.12 if bool(row["display_clipped"]) else 0),
            pct_label(float(row["endpoint_change_pct"]), bool(row["display_clipped"])),
            ha=ha,
            va="center",
            fontsize=5.6,
            color=color,
        )

    ax.set_title("Endpoint response from rate 0 to 1", loc="left", fontsize=8, pad=7)
    ax.set_xlabel("Endpoint change (%)")
    ax.set_yticks(y_positions)
    ax.set_yticklabels(["Final\npackages", "Avg.\npackage size", "Package-size\ndispersion", "Mitigation\nvalue", "Final\nvalue"], fontsize=5.8)
    ax.set_xlim(-112, 86)
    ax.set_ylim(-0.6, len(metrics) - 0.4)
    ax.set_xticks([-100, -50, 0, 50])
    style_axis(ax, grid_axis="x")
    ax.text(0.02, 0.98, "left: decrease / right: increase", transform=ax.transAxes, ha="left", va="top", fontsize=5.6, color=COLORS["muted"])
    add_panel_label(ax, "c", x=-0.10, y=1.08)


def make_figure(df: pd.DataFrame, endpoint_df: pd.DataFrame) -> plt.Figure:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 7,
            "axes.linewidth": 0.8,
            "axes.labelcolor": COLORS["text"],
            "xtick.color": COLORS["text"],
            "ytick.color": COLORS["text"],
            "text.color": COLORS["text"],
            "legend.frameon": False,
        }
    )

    fig = plt.figure(figsize=(7.05, 4.85), facecolor="white", constrained_layout=False)
    gs = fig.add_gridspec(
        2,
        2,
        height_ratios=[1.18, 1.0],
        width_ratios=[1.05, 1.16],
        left=0.085,
        right=0.982,
        bottom=0.115,
        top=0.855,
        wspace=0.42,
        hspace=0.62,
    )
    ax_a = fig.add_subplot(gs[0, :])
    ax_b = fig.add_subplot(gs[1, 0])
    ax_c = fig.add_subplot(gs[1, 1])

    plot_policy_trajectory(ax_a, df)
    plot_mitigation_lane(ax_b, df)
    plot_endpoint_matrix(ax_c, endpoint_df)

    legend_handles = [
        Line2D([0], [0], color=COLORS["subsidy"], marker="o", markersize=4.2, linewidth=1.4, label=PROFILE_LABELS[SUBSIDY_PANEL]),
        Line2D([0], [0], color=COLORS["tax"], marker="D", markersize=4.2, linewidth=1.4, label=PROFILE_LABELS[TAX_PANEL]),
    ]
    fig.legend(
        handles=legend_handles,
        loc="upper right",
        bbox_to_anchor=(0.982, 0.936),
        ncol=2,
        fontsize=6.6,
        handlelength=1.45,
        columnspacing=1.0,
    )
    fig.text(
        0.085,
        0.974,
        "Case RQ2: carbon taxes and subsidies reshape package design in the 934-task project",
        ha="left",
        va="top",
        fontsize=9,
        fontweight="bold",
        color=COLORS["text"],
    )
    fig.text(
        0.085,
        0.944,
        "One-factor policy sensitivities at discount rate 0.0001; each point is one expanded case-project run.",
        ha="left",
        va="top",
        fontsize=6.8,
        color=COLORS["muted"],
    )
    return fig


def endpoint_lookup(endpoint_df: pd.DataFrame, profile: str, metric: str) -> float:
    return float(endpoint_df[(endpoint_df["profile"] == profile) & (endpoint_df["metric"] == metric)]["endpoint_change_pct"].iloc[0])


def write_caption(df: pd.DataFrame, endpoint_df: pd.DataFrame) -> None:
    subsidy_zero = df[(df["Panel"] == SUBSIDY_PANEL) & np.isclose(df["Focal rate"], 0.0)].iloc[0]
    subsidy_one = df[(df["Panel"] == SUBSIDY_PANEL) & np.isclose(df["Focal rate"], 1.0)].iloc[0]
    tax_zero = df[(df["Panel"] == TAX_PANEL) & np.isclose(df["Focal rate"], 0.0)].iloc[0]
    tax_one = df[(df["Panel"] == TAX_PANEL) & np.isclose(df["Focal rate"], 1.0)].iloc[0]
    capped_count = int((df["Stop"] == "iteration cap").sum())
    subsidy_value_change = endpoint_lookup(endpoint_df, "subsidy_varied", "Final value")
    tax_value_change = endpoint_lookup(endpoint_df, "tax_varied", "Final value")

    status_sentence = (
        f"All {len(df)} runs converged."
        if capped_count == 0
        else f"Filled markers denote converged runs; open markers denote the {capped_count} iteration-cap incumbents."
    )
    text = f"""# Figure 11. Policy-Response Mechanism Map in the 934-Task Case Study

The figure summarizes RQ2 using one-factor policy sensitivities for the expanded 934-task case project at discount rate 0.0001. The subsidy profile varies the green subsidy rate while fixing carbon tax at 0.5; the tax profile varies the carbon tax rate while fixing green subsidy at 0.5. **a**, Policy trajectory map: average package size is plotted against optimized final project value, and marker area encodes mitigation value. **b**, Mitigation response lane across the tested focal rates. **c**, Endpoint response matrix from rate 0 to rate 1 for package count, average package size, package-size dispersion, mitigation value, and final project value. Each point is one case-project run. {status_sentence} As the subsidy rate increases from 0 to 1.0, final value improves from {subsidy_zero['Final value']:,.2f} to {subsidy_one['Final value']:,.2f} ({subsidy_value_change:+.2f}%), while mitigation declines from {subsidy_zero['Mitigation value']:,.2f} to {subsidy_one['Mitigation value']:,.2f}. As the tax rate increases from 0 to 1.0, final value falls from {tax_zero['Final value']:,.2f} to {tax_one['Final value']:,.2f} ({tax_value_change:+,.2f}%), while mitigation rises from {tax_zero['Mitigation value']:,.2f} to {tax_one['Mitigation value']:,.2f}. Lines connect observed focal-rate cells and are not fitted response curves.
"""
    CAPTION_MD.write_text(text, encoding="utf-8")


def write_qa(df: pd.DataFrame, endpoint_df: pd.DataFrame, plot_data: pd.DataFrame) -> None:
    base = df[np.isclose(df["Focal rate"], 0.5)]
    capped = df[df["Stop"] == "iteration cap"]
    svg_path = FIGURE_STEM.with_suffix(".svg")
    svg_text = svg_path.read_text(encoding="utf-8", errors="ignore")
    text_nodes = svg_text.count("<text")
    panel_counts = plot_data.groupby("panel").size().to_dict()
    clipped = endpoint_df[endpoint_df["display_clipped"]]
    text = f"""# QA Note: Case RQ2 Policy Sensitivity Figure

- Backend: Python/matplotlib only.
- Source main-table rows: {len(df)}.
- Sensitivity profiles: {', '.join(PROFILE_LABELS[p] for p in PROFILE_ORDER)}.
- Focal rates per profile: {', '.join(RATE_LABELS)}.
- Base-case rows at focal rate 0.5: {len(base)}; shared final packages = {int(base['Final packages'].iloc[0])}.
- Iteration-cap rows encoded with open markers: {len(capped)}.
- Iteration-cap focal rates: {', '.join(format_rate(v) for v in capped['Focal rate'])}.
- Plot-data row counts by panel: {panel_counts}.
- Endpoint rows exported for Panel c: {len(endpoint_df)}.
- Clipped endpoint display rows: {len(clipped)}.
- SVG text nodes detected: {text_nodes}.
- SVG text remains editable through matplotlib `svg.fonttype = none`.
- PDF font type is set to TrueType through matplotlib `pdf.fonttype = 42`.
- TIFF export resolution: 600 dpi.
- No inferential intervals, p-values, fitted trends, synthetic policy-rate cells, or post-hoc value edits were added.

Panel c clips only the visual lollipop length for extreme endpoint percentages while preserving exact endpoint values in the plot-data CSV and labels. Paths in Panel a and bands in Panel b connect observed focal-rate cells only.
"""
    QA_MD.write_text(text, encoding="utf-8")


def save_figure(fig: plt.Figure) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIGURE_STEM.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".png"), dpi=300, bbox_inches="tight")
    preview = FIGURE_STEM.with_name(FIGURE_STEM.name + "_preview").with_suffix(".png")
    fig.savefig(preview, dpi=260, bbox_inches="tight")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df = load_and_validate()
    endpoint_df = build_endpoint_data(df)
    plot_data = build_plot_data(df, endpoint_df)
    plot_data.to_csv(PLOT_DATA_CSV, index=False)
    fig = make_figure(df, endpoint_df)
    save_figure(fig)
    plt.close(fig)
    write_caption(df, endpoint_df)
    write_qa(df, endpoint_df, plot_data)
    print(f"Saved figure bundle to {OUTPUT_DIR}")
    print(f"Saved plotting data to {PLOT_DATA_CSV}")


if __name__ == "__main__":
    main()

"""Create the case-study RQ1 work-package mitigation figure.

The script follows the figure contract in
planning/nature_figure_contract_case_rq1_work_package_mitigation.md. It reads
the processed case-study RQ1 tables and exports a publication-ready figure
bundle plus the exact plotting data used in each panel.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter


PROJECT_ROOT = Path(r"C:\files\Documents\.codex\work_package_tax_carbon_research")
DATA_DIR = PROJECT_ROOT / "R1/manuscript_component/carbon_case_update/data"
DIST_CSV = DATA_DIR / "case_rq1_package_size_distribution.csv"
SUMMARY_CSV = DATA_DIR / "case_rq1_summary.csv"
OUTPUT_DIR = PROJECT_ROOT / "R1/manuscript_component/carbon_case_update/figures"
FIGURE_STEM = OUTPUT_DIR / "fig_large_case_rq1_work_package_mitigation"
PLOT_DATA_CSV = OUTPUT_DIR / "fig_large_case_rq1_work_package_mitigation_plot_data.csv"
CAPTION_MD = OUTPUT_DIR / "fig_large_case_rq1_work_package_mitigation_caption.md"
QA_MD = OUTPUT_DIR / "fig_large_case_rq1_work_package_mitigation_qa.md"

EXPECTED_PACKAGE_SIZES = [1, 2, 3, 4, 5, 7, 10, 11]
DIST_COLUMNS = ["Package size", "Package count", "Share (%)"]
SUMMARY_NUMERIC_COLUMNS = [
    "Initial packages",
    "Final packages",
    "Package reduction",
    "Package reduction (%)",
    "Initial value",
    "Final value",
    "Mitigation value",
    "Mitigation ratio (%)",
    "Final average package size",
    "STD package size",
    "Singleton packages",
    "Multi-task packages",
    "Max package size",
    "Final makespan",
    "Subsidy PV",
    "Tax PV",
    "Setup PV",
]

COLORS = {
    "singleton": "#7B8794",
    "bundle": "#4C78A8",
    "coverage": "#6E78B8",
    "mitigation": "#2A9D8F",
    "reference": "#D1D5DB",
    "grid": "#E5E7EB",
    "text": "#111827",
    "muted": "#6B7280",
}


def load_and_validate() -> tuple[pd.DataFrame, pd.Series]:
    dist = pd.read_csv(DIST_CSV)
    summary_df = pd.read_csv(SUMMARY_CSV)

    dist = dist.rename(
        columns={
            "task_count": "Package size",
            "package_count": "Package count",
            "package_share_pct": "Share (%)",
        }
    )
    summary_df = summary_df.rename(
        columns={
            "initial_packages": "Initial packages",
            "final_packages": "Final packages",
            "package_reduction": "Package reduction",
            "package_reduction_pct": "Package reduction (%)",
            "initial_value": "Initial value",
            "final_value": "Final value",
            "mitigation_value": "Mitigation value",
            "mitigation_ratio_pct": "Mitigation ratio (%)",
            "mean_package_size": "Final average package size",
            "STD_package_size": "STD package size",
            "singleton_packages": "Singleton packages",
            "multi_task_packages": "Multi-task packages",
            "max_package_size": "Max package size",
            "final_makespan": "Final makespan",
            "subsidy_pv": "Subsidy PV",
            "tax_pv": "Tax PV",
            "setup_pv": "Setup PV",
            "stopped_by": "Stop",
        }
    )

    missing_dist = set(DIST_COLUMNS).difference(dist.columns)
    if missing_dist:
        raise ValueError(f"Missing distribution columns: {sorted(missing_dist)}")

    required_summary = set(SUMMARY_NUMERIC_COLUMNS + ["Stop"])
    missing_summary = required_summary.difference(summary_df.columns)
    if missing_summary:
        raise ValueError(f"Missing summary columns: {sorted(missing_summary)}")

    if len(dist) != 8:
        raise ValueError(f"Expected 8 distribution rows, found {len(dist)}")
    if len(summary_df) != 1:
        raise ValueError(f"Expected 1 summary row, found {len(summary_df)}")

    for column in DIST_COLUMNS:
        dist[column] = pd.to_numeric(dist[column], errors="raise")
    for column in SUMMARY_NUMERIC_COLUMNS:
        summary_df[column] = pd.to_numeric(summary_df[column], errors="raise")

    dist = dist.sort_values("Package size").reset_index(drop=True)
    package_sizes = dist["Package size"].astype(int).tolist()
    if package_sizes != EXPECTED_PACKAGE_SIZES:
        raise ValueError(f"Unexpected package sizes: {package_sizes}")

    summary = summary_df.iloc[0]
    final_packages = int(summary["Final packages"])
    singleton_packages = int(summary["Singleton packages"])
    multi_task_packages = int(summary["Multi-task packages"])
    initial_packages = int(summary["Initial packages"])
    package_reduction = int(summary["Package reduction"])
    active_tasks = int((dist["Package size"] * dist["Package count"]).sum())

    if int(dist["Package count"].sum()) != final_packages:
        raise ValueError("Package counts do not sum to final package count")
    if active_tasks != 934:
        raise ValueError(f"Unexpected active task count represented by final packages: {active_tasks}")
    if not np.isclose(dist["Share (%)"].sum(), 100.0, atol=1e-4):
        raise ValueError("Package shares do not sum to 100 percent")
    size_one_count = int(dist.loc[dist["Package size"] == 1, "Package count"].iloc[0])
    if size_one_count != singleton_packages:
        raise ValueError("Singleton count does not match package-size distribution")
    multitask_count = int(dist.loc[dist["Package size"] > 1, "Package count"].sum())
    if multitask_count != multi_task_packages:
        raise ValueError("Multi-task count does not match package-size distribution")
    if initial_packages - final_packages != package_reduction:
        raise ValueError("Package reduction is inconsistent with initial and final counts")
    if not np.isclose(summary["Final value"] - summary["Initial value"], summary["Mitigation value"], atol=1e-6):
        raise ValueError("Mitigation value is inconsistent with initial and final values")

    return dist, summary


def augment_distribution(dist: pd.DataFrame, summary: pd.Series) -> pd.DataFrame:
    active_tasks = float((dist["Package size"] * dist["Package count"]).sum())
    out = dist.copy()
    out["task_count"] = out["Package size"] * out["Package count"]
    out["task_share_pct"] = 100 * out["task_count"] / active_tasks
    out["cumulative_task_share_pct"] = out["task_share_pct"].cumsum()
    out["architecture_class"] = np.where(out["Package size"].eq(1), "Singleton control unit", "Multi-task bundle")
    out["active_tasks"] = active_tasks
    out["multi_task_package_share_pct"] = 100 * float(summary["Multi-task packages"]) / float(summary["Final packages"])
    out["multi_task_task_share_pct"] = 100 * out.loc[out["Package size"] > 1, "task_count"].sum() / active_tasks
    return out


def compute_summary_metrics(dist: pd.DataFrame, summary: pd.Series) -> dict[str, float]:
    active_tasks = float(dist["task_count"].sum())
    multitask = dist[dist["Package size"] > 1]
    initial_loss = abs(float(summary["Initial value"]))
    final_loss = abs(float(summary["Final value"]))
    return {
        "active_tasks": active_tasks,
        "multi_task_package_share_pct": 100 * float(summary["Multi-task packages"]) / float(summary["Final packages"]),
        "multi_task_task_share_pct": 100 * float(multitask["task_count"].sum()) / active_tasks,
        "singleton_package_share_pct": 100 * float(summary["Singleton packages"]) / float(summary["Final packages"]),
        "optimized_package_index_pct": 100 * float(summary["Final packages"]) / float(summary["Initial packages"]),
        "initial_loss_abs": initial_loss,
        "final_loss_abs": final_loss,
        "residual_loss_pct": 100 * final_loss / initial_loss,
        "project_value_gain_k": float(summary["Mitigation value"]) / 1000.0,
    }


def build_plot_data(dist: pd.DataFrame, summary: pd.Series, metrics: dict[str, float]) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for _, row in dist.iterrows():
        rows.append(
            {
                "panel": "a",
                "metric": "package_size_distribution_and_task_coverage",
                "source_table": "case_rq1_package_size_distribution.csv",
                "source_column": "Package size; Package count; Share (%)",
                "package_size": int(row["Package size"]),
                "package_count": int(row["Package count"]),
                "package_share_pct": row["Share (%)"],
                "task_count": int(row["task_count"]),
                "task_share_pct": row["task_share_pct"],
                "cumulative_task_share_pct": row["cumulative_task_share_pct"],
                "architecture_class": row["architecture_class"],
                "active_tasks": metrics["active_tasks"],
                "multi_task_package_share_pct": metrics["multi_task_package_share_pct"],
                "multi_task_task_share_pct": metrics["multi_task_task_share_pct"],
                "unit": "percent",
            }
        )

    for stage, count in [("Initialized", summary["Initial packages"]), ("Optimized", summary["Final packages"])]:
        rows.append(
            {
                "panel": "b",
                "metric": "package_count_reduction",
                "source_table": "case_rq1_summary.csv",
                "source_column": "Initial packages; Final packages; Package reduction; Package reduction (%)",
                "stage": stage,
                "package_count": count,
                "package_reduction": summary["Package reduction"],
                "package_reduction_pct": summary["Package reduction (%)"],
                "optimized_package_index_pct": metrics["optimized_package_index_pct"],
                "unit": "packages",
            }
        )

    for stage, value in [("Initialized", summary["Initial value"]), ("Optimized", summary["Final value"])]:
        rows.append(
            {
                "panel": "c",
                "metric": "project_value_improvement",
                "source_table": "case_rq1_summary.csv",
                "source_column": "Initial value; Final value; Mitigation value; Mitigation ratio (%)",
                "stage": stage,
                "project_value": value,
                "project_value_k": value / 1000.0,
                "mitigation_value": summary["Mitigation value"],
                "mitigation_ratio_pct": summary["Mitigation ratio (%)"],
                "residual_loss_pct": metrics["residual_loss_pct"],
                "unit": "objective_units",
            }
        )

    rows.append(
        {
            "panel": "summary",
            "metric": "final_partition_summary",
            "source_table": "case_rq1_summary.csv",
            "final_average_package_size": summary["Final average package size"],
            "std_package_size": summary["STD package size"],
            "singleton_packages": summary["Singleton packages"],
            "multi_task_packages": summary["Multi-task packages"],
            "max_package_size": summary["Max package size"],
            "final_makespan": summary["Final makespan"],
            "subsidy_pv": summary["Subsidy PV"],
            "tax_pv": summary["Tax PV"],
            "setup_pv": summary["Setup PV"],
            "stop": summary["Stop"],
        }
    )
    return pd.DataFrame(rows)


def pct_tick(value: float, _pos: object | None = None) -> str:
    return f"{value:.0f}"


def value_k_tick(value: float, _pos: object | None = None) -> str:
    return f"{value:.0f}"


def style_axis(ax: plt.Axes, grid: bool = True) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#9CA3AF")
    ax.spines["bottom"].set_color("#9CA3AF")
    ax.tick_params(axis="both", colors=COLORS["text"], labelsize=7, width=0.7, length=3)
    if grid:
        ax.yaxis.grid(True, color=COLORS["grid"], linewidth=0.6)
    ax.xaxis.grid(False)
    ax.set_axisbelow(True)


def add_panel_label(ax: plt.Axes, label: str, x: float = -0.085, y: float = 1.08) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8,
        fontweight="bold",
        color=COLORS["text"],
    )


def plot_distribution(ax: plt.Axes, dist: pd.DataFrame, summary: pd.Series, metrics: dict[str, float]) -> None:
    x = dist["Package size"].to_numpy(dtype=float)
    share = dist["Share (%)"].to_numpy(dtype=float)
    cumulative_tasks = dist["cumulative_task_share_pct"].to_numpy(dtype=float)
    colors = np.where(dist["Package size"].eq(1), COLORS["singleton"], COLORS["bundle"])

    max_size = float(x.max())
    ax.axvspan(1.5, max_size + 0.55, color=COLORS["bundle"], alpha=0.045, linewidth=0, zorder=0)
    ax.bar(x, share, width=0.58, color=colors, edgecolor="white", linewidth=0.7, zorder=3)
    ax_coverage = ax.twinx()
    ax_coverage.plot(x, cumulative_tasks, color=COLORS["coverage"], linewidth=1.7, marker="o", markersize=4.0, zorder=4)
    ax_coverage.set_ylim(0, 108)
    ax_coverage.set_yticks([0, 20, 40, 60, 80, 100])
    ax_coverage.yaxis.set_major_formatter(FuncFormatter(pct_tick))
    ax_coverage.set_ylabel("Cumulative task coverage (%)", fontsize=7, color=COLORS["coverage"], labelpad=7)
    ax_coverage.tick_params(axis="y", colors=COLORS["coverage"], labelsize=7, width=0.7, length=3)
    ax_coverage.spines["right"].set_visible(True)
    ax_coverage.spines["right"].set_color(COLORS["coverage"])
    for side in ["left", "top", "bottom"]:
        ax_coverage.spines[side].set_visible(False)
    ax_coverage.grid(False)

    for xi, yi, count in zip(x, share, dist["Package count"]):
        if xi in {1, 2, 3, 4}:
            ax.text(xi, yi + 2.1, f"{int(count)}", ha="center", va="bottom", fontsize=6.2, color=COLORS["text"])

    ax.text(
        1.04,
        share[0] + 7.0,
        f"singleton\n{int(summary['Singleton packages'])} packages",
        ha="left",
        va="bottom",
        fontsize=6.4,
        color=COLORS["singleton"],
    )
    ax.text(
        max_size * 0.66,
        71.0,
        f"multi-task packages\n{metrics['multi_task_task_share_pct']:.1f}% of tasks",
        ha="left",
        va="center",
        fontsize=6.4,
        color=COLORS["coverage"],
    )
    ax.text(
        max_size - 0.15,
        cumulative_tasks[-1] - 3.5,
        "cumulative\ntask coverage",
        ha="right",
        va="top",
        fontsize=6.2,
        color=COLORS["coverage"],
    )
    ax.text(
        0.985,
        0.11,
        f"mean {summary['Final average package size']:.2f}; SD {summary['STD package size']:.2f}; max {int(summary['Max package size'])}",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=6.3,
        color=COLORS["muted"],
    )
    ax.set_title("Optimized package-size distribution", loc="left", fontsize=8, pad=7)
    ax.set_xlabel("Package size (tasks)", fontsize=7)
    ax.set_ylabel("Package share (%)", fontsize=7)
    ax.set_xticks(x)
    ax.set_xticklabels([str(int(v)) for v in x])
    ax.set_xlim(0.45, max_size + 0.55)
    ax.set_ylim(0, 108)
    ax.set_yticks([0, 20, 40, 60, 80, 100])
    ax.yaxis.set_major_formatter(FuncFormatter(pct_tick))
    style_axis(ax)
    add_panel_label(ax, "a", x=-0.045, y=1.09)

    handles = [
        Line2D([0], [0], color=COLORS["singleton"], marker="s", linewidth=0, markersize=6, label="package share"),
        Line2D([0], [0], color=COLORS["coverage"], marker="o", linewidth=1.4, markersize=4, label="cumulative task coverage"),
    ]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.54, 1.04), ncol=2, fontsize=6.3, handlelength=1.5, columnspacing=1.0)


def plot_package_reduction(ax: plt.Axes, summary: pd.Series, metrics: dict[str, float]) -> None:
    stages = ["Initialized", "Optimized"]
    values = [float(summary["Initial packages"]), float(summary["Final packages"])]
    colors = [COLORS["singleton"], COLORS["bundle"]]
    x = np.arange(len(stages))

    ax.bar(x, values, width=0.48, color=colors, edgecolor="white", linewidth=0.8, zorder=3)
    ax.plot(x, values, color=COLORS["reference"], linewidth=1.1, zorder=4)
    ax.scatter(x, values, s=30, color=colors, edgecolor="white", linewidth=0.7, zorder=5)
    for xi, value in zip(x, values):
        ax.text(xi, value + 8, f"{int(value)}", ha="center", va="bottom", fontsize=7, color=COLORS["text"])

    ax.annotate(
        f"{int(summary['Package reduction'])} fewer\n({summary['Package reduction (%)']:.1f}%)",
        xy=(0.5, (values[0] + values[1]) / 2),
        xytext=(0.5, max(values) * 0.54),
        ha="center",
        va="center",
        fontsize=6.7,
        color=COLORS["bundle"],
        arrowprops={"arrowstyle": "->", "lw": 0.8, "color": COLORS["bundle"], "shrinkA": 2, "shrinkB": 2},
    )
    ax.set_title("Package-count reduction", loc="left", fontsize=8, pad=7)
    ax.set_ylabel("Number of packages", fontsize=7)
    ax.set_xticks(x)
    ax.set_xticklabels(stages)
    ax.set_ylim(0, max(values) * 1.16)
    ax.set_xlim(-0.55, 1.55)
    style_axis(ax)
    add_panel_label(ax, "b")


def plot_value_improvement(ax: plt.Axes, summary: pd.Series) -> None:
    stages = ["Initialized", "Optimized"]
    values_k = np.array([float(summary["Initial value"]), float(summary["Final value"])]) / 1000.0
    x = np.arange(len(stages))

    ax.plot(x, values_k, color=COLORS["mitigation"], linewidth=1.8, marker="o", markersize=5.2, zorder=4)
    ax.scatter(x, values_k, s=44, color=COLORS["mitigation"], edgecolor="white", linewidth=0.8, zorder=5)
    for xi, value_k in zip(x, values_k):
        ax.text(xi, value_k - 0.65, f"{value_k:.2f}", ha="center", va="top", fontsize=6.7, color=COLORS["text"])

    ax.annotate(
        f"+{summary['Mitigation value']:,.0f}\n({summary['Mitigation ratio (%)']:.1f}%)",
        xy=(0.55, values_k.mean()),
        xytext=(0.30, values_k.mean() + 1.8),
        ha="center",
        va="center",
        fontsize=6.7,
        color=COLORS["mitigation"],
        arrowprops={"arrowstyle": "->", "lw": 0.8, "color": COLORS["mitigation"], "shrinkA": 2, "shrinkB": 2},
    )
    ax.annotate(
        "higher is better",
        xy=(0.90, 0.90),
        xytext=(0.57, 0.90),
        xycoords="axes fraction",
        textcoords="axes fraction",
        ha="left",
        va="center",
        fontsize=6.3,
        color=COLORS["muted"],
        arrowprops={"arrowstyle": "->", "lw": 0.7, "color": COLORS["muted"]},
    )
    ax.set_title("Project-value improvement", loc="left", fontsize=8, pad=7)
    ax.set_ylabel("Project value (x 1,000)", fontsize=7)
    ax.set_xticks(x)
    ax.set_xticklabels(stages)
    ax.set_xlim(-0.35, 1.35)
    ax.set_ylim(min(values_k) - 1.5, max(values_k) + 2.5)
    ax.yaxis.set_major_formatter(FuncFormatter(value_k_tick))
    style_axis(ax)
    add_panel_label(ax, "c")


def make_figure(dist: pd.DataFrame, summary: pd.Series, metrics: dict[str, float]) -> plt.Figure:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 7,
            "axes.linewidth": 0.8,
            "axes.labelcolor": COLORS["text"],
            "xtick.color": COLORS["text"],
            "ytick.color": COLORS["text"],
            "text.color": COLORS["text"],
            "legend.frameon": False,
        }
    )

    fig = plt.figure(figsize=(7.05, 4.72), facecolor="white", constrained_layout=False)
    gs = fig.add_gridspec(
        2,
        2,
        height_ratios=[1.28, 1.0],
        left=0.082,
        right=0.982,
        bottom=0.116,
        top=0.858,
        hspace=0.62,
        wspace=0.34,
    )
    ax_distribution = fig.add_subplot(gs[0, :])
    ax_reduction = fig.add_subplot(gs[1, 0])
    ax_value = fig.add_subplot(gs[1, 1])

    # Reserve right-side annotation space in panel a only; panels b/c retain their positions.
    pos = ax_distribution.get_position()
    ax_distribution.set_position([pos.x0, pos.y0, pos.width - 0.045, pos.height])
    plot_distribution(ax_distribution, dist, summary, metrics)
    plot_package_reduction(ax_reduction, summary, metrics)
    plot_value_improvement(ax_value, summary)

    fig.text(
        0.082,
        0.974,
        "Case RQ1: optimized package distribution and mitigation effect in the 934-task project",
        ha="left",
        va="top",
        fontsize=9,
        fontweight="bold",
        color=COLORS["text"],
    )
    fig.text(
        0.082,
        0.943,
        "Representative case run: carbon tax 0.5, green subsidy 0.5, discount rate 0.0001.",
        ha="left",
        va="top",
        fontsize=6.8,
        color=COLORS["muted"],
    )
    return fig


def write_caption(summary: pd.Series, metrics: dict[str, float]) -> None:
    text = f"""# Figure 10. Optimized Work-Package Distribution and Mitigation Effect in the 934-Task Case Study

The figure summarizes the representative case run under carbon tax rate 0.5,
green subsidy rate 0.5, and discount rate 0.0001. **a**, Package-size
distribution in the optimized final partition. Bars report the share of final
packages at each package size, and the line reports cumulative project-task
coverage. The optimized plan contains {int(summary['Final packages'])} final
packages and {int(metrics['active_tasks'])} project tasks. The
{int(summary['Singleton packages'])} singleton packages account for
{metrics['singleton_package_share_pct']:.2f}% of final packages, whereas the
{int(summary['Multi-task packages'])} multi-task packages account for
{metrics['multi_task_package_share_pct']:.2f}% of final packages but
{metrics['multi_task_task_share_pct']:.2f}% of project tasks. **b**,
Package-count reduction from {int(summary['Initial packages'])} initialized
packages to {int(summary['Final packages'])} optimized packages, a reduction of
{int(summary['Package reduction'])} packages or
{summary['Package reduction (%)']:.2f}%. **c**, Project-value improvement from
{summary['Initial value']:,.2f} to {summary['Final value']:,.2f}, yielding a
mitigation value of {summary['Mitigation value']:,.2f} or
{summary['Mitigation ratio (%)']:.2f}% of the initialized cash-flow loss.
Values are descriptive summaries of one expanded case run; no inferential
intervals are reported.
"""
    CAPTION_MD.write_text(text, encoding="utf-8")


def write_qa(dist: pd.DataFrame, summary: pd.Series, metrics: dict[str, float], plot_data: pd.DataFrame) -> None:
    svg_path = FIGURE_STEM.with_suffix(".svg")
    svg_text = svg_path.read_text(encoding="utf-8", errors="ignore")
    text_nodes = svg_text.count("<text")
    panel_counts = plot_data.groupby("panel").size().to_dict()
    text = f"""# QA Note: Case RQ1 Work Package Mitigation Figure

- Backend: Python/matplotlib only.
- Source distribution rows: {len(dist)}.
- Source summary rows: 1.
- Package counts sum to final packages: {int(dist['Package count'].sum())} = {int(summary['Final packages'])}.
- Package-size-weighted counts sum to all project tasks: {int(dist['task_count'].sum())}.
- Singleton packages: {int(summary['Singleton packages'])}.
- Multi-task packages: {int(summary['Multi-task packages'])}.
- Multi-task package share: {metrics['multi_task_package_share_pct']:.6f}%.
- Multi-task task share: {metrics['multi_task_task_share_pct']:.6f}%.
- Package reduction: {int(summary['Initial packages'])} - {int(summary['Final packages'])} = {int(summary['Package reduction'])}.
- Value improvement: {summary['Final value'] - summary['Initial value']:.6f}.
- Reported mitigation value: {summary['Mitigation value']:.6f}.
- Plot-data row counts by panel: {panel_counts}.
- SVG text nodes detected: {text_nodes}.
- Algorithm stop status: {summary['Stop']}.
- SVG text remains editable through matplotlib `svg.fonttype = none`.
- PDF font type is set to TrueType through matplotlib `pdf.fonttype = 42`.
- TIFF export resolution: 600 dpi.
- No inferential intervals, p-values, fitted trends, synthetic observations, smoothing, or post-hoc value edits were added.
"""
    QA_MD.write_text(text, encoding="utf-8")


def save_figure(fig: plt.Figure) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIGURE_STEM.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(
        FIGURE_STEM.with_name(FIGURE_STEM.name + "_preview").with_suffix(".png"),
        dpi=260,
        bbox_inches="tight",
    )


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    dist, summary = load_and_validate()
    dist = augment_distribution(dist, summary)
    metrics = compute_summary_metrics(dist, summary)
    plot_data = build_plot_data(dist, summary, metrics)
    plot_data.to_csv(PLOT_DATA_CSV, index=False)
    fig = make_figure(dist, summary, metrics)
    save_figure(fig)
    plt.close(fig)
    write_caption(summary, metrics)
    write_qa(dist, summary, metrics, plot_data)
    print(f"Saved figure bundle to {OUTPUT_DIR}")
    print(f"Saved plotting data to {PLOT_DATA_CSV}")


if __name__ == "__main__":
    main()

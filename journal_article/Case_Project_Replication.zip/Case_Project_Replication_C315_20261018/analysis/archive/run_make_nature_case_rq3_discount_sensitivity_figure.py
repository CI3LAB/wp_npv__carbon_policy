"""Create the case-study RQ3 discount-sensitivity mechanism figure.

The script follows the figure contract in
planning/nature_figure_contract_case_rq3_discount_sensitivity.md. It reads the
processed case-study RQ3 discount-sensitivity tables and exports a
publication-ready figure bundle.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(r"C:\files\Documents\.codex\work_package_tax_carbon_research")
TABLE_DIR = PROJECT_ROOT / "R1/manuscript_component/carbon_case_update/data"
MAIN_CSV = TABLE_DIR / "case_rq3_discount_response.csv"
RAW_RESULT_DIR = (
    PROJECT_ROOT
    / "R1"
    / "results"
    / "carbon_case_20260928_161704_d7142dd9"
    / "single_instance_discount_sensitivity"
)
OUTPUT_DIR = PROJECT_ROOT / "R1/manuscript_component/carbon_case_update/figures"
FIGURE_STEM = OUTPUT_DIR / "fig_large_case_rq3_discount_sensitivity"
PLOT_DATA_CSV = OUTPUT_DIR / "fig_large_case_rq3_discount_sensitivity_plot_data.csv"
CAPTION_MD = OUTPUT_DIR / "fig_large_case_rq3_discount_sensitivity_caption.md"
QA_MD = OUTPUT_DIR / "fig_large_case_rq3_discount_sensitivity_qa.md"

DISCOUNT_RATES = [0.0, 0.00005, 0.0001, 0.0002, 0.0005, 0.001]
DISCOUNT_LABELS = ["0", "5e-5", "1e-4", "2e-4", "5e-4", "1e-3"]
MAIN_NUMERIC_COLUMNS = [
    "Discount rate",
    "Initial value",
    "Final value",
    "Mitigation value",
    "Mitigation ratio (%)",
    "Final packages",
    "Avg. package size",
    "Makespan",
]
STRUCTURE_NUMERIC_COLUMNS = [
    "Discount rate",
    "Final packages",
    "Singleton packages",
    "Multi-task packages",
    "Max package size",
    "Avg. package size",
    "STD package size",
    "Package reduction (%)",
    "Makespan",
    "Iterations",
]
TEMPORAL_NUMERIC_COLUMNS = [
    "Discount rate",
    "Early packages",
    "Early avg. size",
    "Early workload share (%)",
    "Middle packages",
    "Middle avg. size",
    "Middle workload share (%)",
    "Late packages",
    "Late avg. size",
    "Late workload share (%)",
]
COLORS = {
    "avg_size": "#4C78A8",
    "std_size": "#7A90B7",
    "early": "#7B8794",
    "middle": "#8E75B8",
    "late": "#C65D60",
    "grid": "#E5E7EB",
    "text": "#111827",
    "muted": "#6B7280",
    "arrow": "#9CA3AF",
}
TRAJECTORY_COLORS = ["#4C78A8", "#5EA4A2", "#2A9D8F", "#E9A23B", "#D4774E", "#C44E52"]


def normalize_stop(value: object) -> str:
    text = str(value).strip().lower().replace("_", " ")
    if text == "iteration cap":
        return "iteration cap"
    if text == "converged":
        return "converged"
    raise ValueError(f"Unexpected stop status: {value!r}")


def format_discount_label(value: float) -> str:
    for rate, label in zip(DISCOUNT_RATES, DISCOUNT_LABELS):
        if abs(value - rate) < 1e-12:
            return label
    return f"{value:g}"


def sort_by_discount(df: pd.DataFrame) -> pd.DataFrame:
    order_map = {round(rate, 10): i for i, rate in enumerate(DISCOUNT_RATES)}
    out = df.copy()
    out["_order"] = out["Discount rate"].round(10).map(order_map)
    if out["_order"].isna().any():
        raise ValueError("Unexpected discount rate found")
    return out.sort_values("_order").drop(columns="_order").reset_index(drop=True)


def scenario_folder(rate: float) -> str:
    mapping = {
        0.0: "discount_0",
        0.00005: "discount_5e-05",
        0.0001: "discount_0p0001",
        0.0002: "discount_0p0002",
        0.0005: "discount_0p0005",
        0.001: "discount_0p001",
    }
    for expected, folder in mapping.items():
        if np.isclose(rate, expected, atol=1e-12):
            return folder
    raise ValueError(f"Unsupported discount rate: {rate}")


def prepare_large_case_tables() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    source = pd.read_csv(MAIN_CSV).sort_values("discount_rate").reset_index(drop=True)
    main = source.rename(
        columns={
            "discount_rate": "Discount rate",
            "initial_value": "Initial value",
            "final_value": "Final value",
            "mitigation_value": "Mitigation value",
            "mitigation_ratio_pct": "Mitigation ratio (%)",
            "final_packages": "Final packages",
            "mean_package_size": "Avg. package size",
            "final_makespan": "Makespan",
            "stopped_by": "Stop",
        }
    )
    main = main[MAIN_NUMERIC_COLUMNS + ["Stop"]].copy()

    structure_rows: list[dict[str, float]] = []
    temporal_rows: list[dict[str, float]] = []
    for row in source.itertuples(index=False):
        rate = float(row.discount_rate)
        packages = pd.read_csv(RAW_RESULT_DIR / scenario_folder(rate) / "final_work_packages.csv")
        if len(packages) != int(row.final_packages):
            raise ValueError(f"Package-count mismatch at discount rate {rate}")

        structure_rows.append(
            {
                "Discount rate": rate,
                "Final packages": int(row.final_packages),
                "Singleton packages": int(packages["task_count"].eq(1).sum()),
                "Multi-task packages": int(packages["task_count"].gt(1).sum()),
                "Max package size": int(packages["task_count"].max()),
                "Avg. package size": float(packages["task_count"].mean()),
                "STD package size": float(packages["task_count"].std(ddof=1)),
                "Package reduction (%)": float(row.package_reduction_pct),
                "Makespan": float(row.final_makespan),
                "Iterations": int(row.iterations),
            }
        )

        normalized_start = packages["start_time"] / float(row.final_makespan)
        stages = pd.cut(
            normalized_start,
            bins=[-0.001, 1.0 / 3.0, 2.0 / 3.0, 1.001],
            labels=["Early", "Middle", "Late"],
        )
        total_workload = float(packages["workload"].sum())
        temporal_row: dict[str, float] = {"Discount rate": rate}
        for stage in ["Early", "Middle", "Late"]:
            subset = packages[stages == stage]
            temporal_row[f"{stage} packages"] = int(len(subset))
            temporal_row[f"{stage} avg. size"] = float(subset["task_count"].mean()) if len(subset) else 0.0
            temporal_row[f"{stage} workload share (%)"] = (
                100.0 * float(subset["workload"].sum()) / total_workload if total_workload else 0.0
            )
        temporal_rows.append(temporal_row)

    return main, pd.DataFrame(structure_rows), pd.DataFrame(temporal_rows)


def load_and_validate() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    main, structure, temporal = prepare_large_case_tables()

    required = {
        "main": set(MAIN_NUMERIC_COLUMNS + ["Stop"]),
        "structure": set(STRUCTURE_NUMERIC_COLUMNS),
        "temporal": set(TEMPORAL_NUMERIC_COLUMNS),
    }
    missing = {
        "main": required["main"].difference(main.columns),
        "structure": required["structure"].difference(structure.columns),
        "temporal": required["temporal"].difference(temporal.columns),
    }
    missing = {name: values for name, values in missing.items() if values}
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    for column in MAIN_NUMERIC_COLUMNS:
        main[column] = pd.to_numeric(main[column], errors="raise")
    main["Stop"] = main["Stop"].map(normalize_stop)
    for column in STRUCTURE_NUMERIC_COLUMNS:
        structure[column] = pd.to_numeric(structure[column], errors="raise")
    for column in TEMPORAL_NUMERIC_COLUMNS:
        temporal[column] = pd.to_numeric(temporal[column], errors="raise")

    main = sort_by_discount(main)
    structure = sort_by_discount(structure)
    temporal = sort_by_discount(temporal)

    for name, table in [("main", main), ("structure", structure), ("temporal", temporal)]:
        if len(table) != 6:
            raise ValueError(f"Expected 6 rows in {name}, found {len(table)}")
        observed = table["Discount rate"].round(10).tolist()
        expected = [round(value, 10) for value in DISCOUNT_RATES]
        if observed != expected:
            raise ValueError(f"Unexpected discount-rate order in {name}: {observed}")

    for column in ["Final packages", "Avg. package size", "Makespan"]:
        if not np.allclose(main[column].to_numpy(dtype=float), structure[column].to_numpy(dtype=float), atol=1e-6):
            raise ValueError(f"Main and structure tables differ on {column}")

    mitigation_from_values = main["Final value"] - main["Initial value"]
    if not np.allclose(mitigation_from_values, main["Mitigation value"], atol=0.02):
        raise ValueError("Rounded mitigation arithmetic check failed")

    share_sum = (
        temporal["Early workload share (%)"]
        + temporal["Middle workload share (%)"]
        + temporal["Late workload share (%)"]
    )
    if not np.allclose(share_sum, 100.0, atol=0.02):
        raise ValueError("Temporal workload shares do not sum to 100 percent")

    return main, structure, temporal


def add_common_columns(main: pd.DataFrame, structure: pd.DataFrame, temporal: pd.DataFrame) -> None:
    for table in [main, structure, temporal]:
        table["discount_order"] = range(len(table))
        table["discount_label"] = [format_discount_label(v) for v in table["Discount rate"]]
    main["marker_status"] = np.where(main["Stop"] == "iteration cap", "iteration_cap", "converged")
    main["final_value_k"] = main["Final value"] / 1000.0
    main["mitigation_value_k"] = main["Mitigation value"] / 1000.0
    main["marker_size"] = 45 + 2.55 * main["Mitigation ratio (%)"]


def build_plot_data(main: pd.DataFrame, structure: pd.DataFrame, temporal: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []

    for idx, row in main.iterrows():
        rows.append(
            {
                "panel": "a",
                "metric": "financial trajectory",
                "source_table": "case_rq3_discount_response.csv",
                "source_column": "Final value; Mitigation value; Mitigation ratio (%)",
                "discount_rate": row["Discount rate"],
                "discount_label": row["discount_label"],
                "x_position": row["discount_order"],
                "x_value": row["final_value_k"],
                "y_value": row["mitigation_value_k"],
                "value": row["Mitigation value"],
                "unit": "objective units",
                "transformation": "x=Final value/1000; y=Mitigation value/1000; marker size from Mitigation ratio (%)",
                "stop": row["Stop"],
                "marker_status": row["marker_status"],
                "mitigation_ratio_pct": row["Mitigation ratio (%)"],
                "marker_size": row["marker_size"],
                "final_packages": row["Final packages"],
            }
        )

    panel_b_specs = [
        ("Average package size", "Avg. package size", "tasks"),
        ("SD of package size", "STD package size", "tasks"),
        ("Final packages", "Final packages", "packages"),
        ("Max package size", "Max package size", "tasks"),
    ]
    for metric, column, unit in panel_b_specs:
        for idx, row in structure.iterrows():
            rows.append(
                {
                    "panel": "b",
                    "metric": metric,
                    "source_table": "case_rq3_discount_response.csv; discount_*/final_work_packages.csv",
                    "source_column": column,
                    "discount_rate": row["Discount rate"],
                    "discount_label": row["discount_label"],
                    "x_position": row["discount_order"],
                    "x_value": row["discount_order"],
                    "y_value": row[column],
                    "value": row[column],
                    "unit": unit,
                    "transformation": "none",
                    "stop": main.loc[idx, "Stop"],
                    "marker_status": main.loc[idx, "marker_status"],
                    "mitigation_ratio_pct": main.loc[idx, "Mitigation ratio (%)"],
                    "marker_size": np.nan,
                    "final_packages": structure.loc[idx, "Final packages"],
                }
            )

    panel_c_specs = [
        ("Early workload share", "Early workload share (%)"),
        ("Middle workload share", "Middle workload share (%)"),
        ("Late workload share", "Late workload share (%)"),
    ]
    for metric, column in panel_c_specs:
        for idx, row in temporal.iterrows():
            rows.append(
                {
                    "panel": "c",
                    "metric": metric,
                    "source_table": "discount_*/final_work_packages.csv",
                    "source_column": column,
                    "discount_rate": row["Discount rate"],
                    "discount_label": row["discount_label"],
                    "x_position": row["discount_order"],
                    "x_value": row["discount_order"],
                    "y_value": row[column],
                    "value": row[column],
                    "unit": "%",
                    "transformation": "stacked area share",
                    "stop": main.loc[idx, "Stop"],
                    "marker_status": main.loc[idx, "marker_status"],
                    "mitigation_ratio_pct": main.loc[idx, "Mitigation ratio (%)"],
                    "marker_size": np.nan,
                    "final_packages": main.loc[idx, "Final packages"],
                }
            )
    return pd.DataFrame(rows)


def style_axis(ax: plt.Axes, y_grid: bool = True) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#9CA3AF")
    ax.spines["bottom"].set_color("#9CA3AF")
    ax.tick_params(axis="both", colors=COLORS["text"], labelsize=7, width=0.7, length=3)
    ax.yaxis.grid(y_grid, color=COLORS["grid"], linewidth=0.65)
    ax.xaxis.grid(False)
    ax.set_axisbelow(True)


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.105,
        1.08,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8,
        fontweight="bold",
        color=COLORS["text"],
    )


def set_discount_axis(ax: plt.Axes) -> None:
    x = np.arange(len(DISCOUNT_RATES))
    ax.set_xticks(x)
    ax.set_xticklabels(DISCOUNT_LABELS)
    ax.set_xlim(-0.25, len(DISCOUNT_RATES) - 0.45)
    ax.set_xlabel("Discount rate", fontsize=7)


def draw_status_markers(
    ax: plt.Axes,
    x: np.ndarray,
    y: np.ndarray,
    stop: pd.Series,
    color: str,
    size: float,
    zorder: int = 5,
) -> None:
    converged = stop == "converged"
    capped = ~converged
    if converged.any():
        ax.scatter(
            x[converged],
            y[converged],
            s=size,
            color=color,
            edgecolor="white",
            linewidth=0.7,
            zorder=zorder,
        )
    if capped.any():
        ax.scatter(
            x[capped],
            y[capped],
            s=size + 6,
            facecolor="white",
            edgecolor=color,
            linewidth=1.15,
            zorder=zorder + 1,
        )


def money_k_tick(value: float, _pos: object | None = None) -> str:
    return f"{value:.0f}"


def make_figure(main: pd.DataFrame, structure: pd.DataFrame, temporal: pd.DataFrame) -> plt.Figure:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 7,
            "axes.linewidth": 0.8,
            "axes.labelcolor": COLORS["text"],
            "xtick.color": COLORS["text"],
            "ytick.color": COLORS["text"],
            "text.color": COLORS["text"],
            "legend.frameon": False,
        }
    )

    fig = plt.figure(figsize=(7.05, 4.85), facecolor="white", constrained_layout=False)
    gs = fig.add_gridspec(
        2,
        2,
        height_ratios=[1.14, 1.0],
        left=0.085,
        right=0.965,
        bottom=0.105,
        top=0.84,
        wspace=0.36,
        hspace=0.58,
    )
    ax_financial = fig.add_subplot(gs[0, :])
    ax_structure = fig.add_subplot(gs[1, 0])
    ax_temporal = fig.add_subplot(gs[1, 1])

    plot_financial_trajectory(ax_financial, main)
    plot_package_structure(ax_structure, main, structure)
    plot_temporal_stream(ax_temporal, main, temporal)

    for ax, panel_label in zip([ax_financial, ax_structure, ax_temporal], ["a", "b", "c"]):
        style_axis(ax)
        add_panel_label(ax, panel_label)

    legend_handles = [
        Line2D([0], [0], color=COLORS["muted"], marker="o", markerfacecolor="#2A9D8F", markersize=5, linewidth=0, label="converged"),
        Line2D([0], [0], color=COLORS["avg_size"], linewidth=1.6, label="average package size"),
        Line2D([0], [0], color=COLORS["std_size"], linewidth=1.6, label="SD of package size"),
    ]
    if (main["Stop"] == "iteration cap").any():
        legend_handles.insert(
            1,
            Line2D([0], [0], color=COLORS["muted"], marker="o", markerfacecolor="white", markersize=5, linewidth=0, label="iteration-cap incumbent"),
        )
    fig.legend(
        handles=legend_handles,
        loc="upper right",
        bbox_to_anchor=(0.965, 0.92),
        ncol=len(legend_handles),
        fontsize=6.6,
        handlelength=1.35,
        columnspacing=1.05,
    )
    fig.text(
        0.085,
        0.975,
        "Case RQ3: discount-response mechanism in the 934-task project",
        ha="left",
        va="top",
        fontsize=9,
        fontweight="bold",
        color=COLORS["text"],
    )
    fig.text(
        0.085,
        0.943,
        "Carbon tax and green subsidy fixed at 0.5; each point is one expanded case-project run.",
        ha="left",
        va="top",
        fontsize=7,
        color=COLORS["muted"],
    )
    return fig


def plot_financial_trajectory(ax: plt.Axes, main: pd.DataFrame) -> None:
    x = main["final_value_k"].to_numpy(dtype=float)
    y = main["mitigation_value_k"].to_numpy(dtype=float)
    sizes = main["marker_size"].to_numpy(dtype=float)
    status = main["Stop"]

    for idx in range(len(x) - 1):
        ax.annotate(
            "",
            xy=(x[idx + 1], y[idx + 1]),
            xytext=(x[idx], y[idx]),
            arrowprops={
                "arrowstyle": "->",
                "lw": 0.85,
                "color": COLORS["arrow"],
                "shrinkA": 12,
                "shrinkB": 12,
                "mutation_scale": 8,
            },
            zorder=1,
        )

    for idx, (x_i, y_i, size_i, color_i) in enumerate(zip(x, y, sizes, TRAJECTORY_COLORS)):
        if status.iloc[idx] == "iteration cap":
            face = "white"
            linewidth = 1.25
        else:
            face = color_i
            linewidth = 0.75
        ax.scatter(
            x_i,
            y_i,
            s=size_i,
            facecolor=face,
            edgecolor=color_i,
            linewidth=linewidth,
            zorder=4,
        )
        if status.iloc[idx] == "iteration cap":
            ax.text(x_i, y_i + 0.75, "cap", ha="center", va="bottom", fontsize=6.1, color=color_i)

    label_offsets = {
        0: (1.5, 0.70),
        2: (-0.35, 1.25),
        4: (-1.0, -2.70),
        5: (-2.0, -2.70),
    }
    for idx, (dx, dy) in label_offsets.items():
        ax.text(
            x[idx] + dx,
            y[idx] + dy,
            main["discount_label"].iloc[idx],
            fontsize=6.5,
            color=TRAJECTORY_COLORS[idx],
            fontweight="bold",
            zorder=7,
        )

    ax.set_title("Financial response trajectory", loc="left", fontsize=8, pad=7)
    ax.set_xlabel("Final project value (x 1,000; higher is better)", fontsize=7)
    ax.set_ylabel("Mitigation value (x 1,000)", fontsize=7)
    ax.xaxis.set_major_formatter(FuncFormatter(money_k_tick))
    ax.yaxis.set_major_formatter(FuncFormatter(money_k_tick))
    ax.set_xlim(min(x) - 1.8, max(x) + 1.8)
    ax.set_ylim(min(0, min(y) - 0.8), max(y) + 1.35)
    ax.text(
        0.02,
        0.93,
        "marker size = mitigation ratio",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=6.4,
        color=COLORS["muted"],
    )
    ax.annotate(
        "higher final value",
        xy=(0.86, 0.12),
        xytext=(0.64, 0.12),
        xycoords="axes fraction",
        textcoords="axes fraction",
        arrowprops={"arrowstyle": "->", "lw": 0.7, "color": COLORS["muted"]},
        ha="left",
        va="center",
        fontsize=6.3,
        color=COLORS["muted"],
    )


def plot_package_structure(ax: plt.Axes, main: pd.DataFrame, structure: pd.DataFrame) -> None:
    x = structure["discount_order"].to_numpy(dtype=float)
    avg = structure["Avg. package size"].to_numpy(dtype=float)
    std = structure["STD package size"].to_numpy(dtype=float)

    ax.fill_between(x, 0, avg, color=COLORS["avg_size"], alpha=0.12, linewidth=0)
    ax.fill_between(x, 0, std, color=COLORS["std_size"], alpha=0.16, linewidth=0)
    ax.plot(x, avg, color=COLORS["avg_size"], linewidth=1.65, zorder=3)
    ax.plot(x, std, color=COLORS["std_size"], linewidth=1.65, zorder=3)
    draw_status_markers(ax, x, avg, main["Stop"], COLORS["avg_size"], 24)
    draw_status_markers(ax, x, std, main["Stop"], COLORS["std_size"], 24)

    ax.set_title("Package-structure response", loc="left", fontsize=8, pad=7)
    ax.set_ylabel("Tasks per package", fontsize=7)
    ax.set_ylim(0, max(avg.max(), std.max()) * 1.22)
    set_discount_axis(ax)
    ax.text(
        x[-1] + 0.16,
        avg[-1],
        "Average",
        ha="left",
        va="center",
        fontsize=6.4,
        color=COLORS["avg_size"],
    )
    ax.text(
        x[-1] + 0.16,
        std[-1],
        "SD",
        ha="left",
        va="center",
        fontsize=6.4,
        color=COLORS["std_size"],
    )
    ax.text(
        0.03,
        0.94,
        f"packages {int(structure['Final packages'].iloc[0])} -> {int(structure['Final packages'].iloc[-1])}\n"
        f"max size {int(structure['Max package size'].iloc[0])} -> {int(structure['Max package size'].iloc[-1])}",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=6.3,
        color=COLORS["muted"],
    )


def plot_temporal_stream(ax: plt.Axes, main: pd.DataFrame, temporal: pd.DataFrame) -> None:
    x = temporal["discount_order"].to_numpy(dtype=float)
    early = temporal["Early workload share (%)"].to_numpy(dtype=float)
    middle = temporal["Middle workload share (%)"].to_numpy(dtype=float)
    late = temporal["Late workload share (%)"].to_numpy(dtype=float)

    ax.stackplot(
        x,
        early,
        middle,
        late,
        colors=[COLORS["early"], COLORS["middle"], COLORS["late"]],
        alpha=0.82,
        linewidth=0,
    )
    ax.plot(x, early, color="white", linewidth=0.8, alpha=0.9)
    ax.plot(x, early + middle, color="white", linewidth=0.8, alpha=0.9)

    final_centers = {
        "Early": early[-1] / 2,
        "Middle": early[-1] + middle[-1] / 2,
        "Late": early[-1] + middle[-1] + late[-1] / 2,
    }
    for label, color in [("Early", COLORS["early"]), ("Middle", COLORS["middle"]), ("Late", COLORS["late"])]:
        ax.text(
            x[-1] + 0.16,
            final_centers[label],
            label,
            ha="left",
            va="center",
            fontsize=6.4,
            color=color,
        )

    capped = main["Stop"] == "iteration cap"
    if capped.any():
        cap_x = x[capped.to_numpy()]
        ax.scatter(cap_x, np.full_like(cap_x, 98.0), s=20, facecolor="white", edgecolor=COLORS["text"], linewidth=0.9, zorder=5)
        for cap in cap_x:
            ax.text(cap, 94.0, "cap", ha="center", va="top", fontsize=5.8, color=COLORS["text"])

    ax.set_title("Temporal workload reallocation", loc="left", fontsize=8, pad=7)
    ax.set_ylabel("Workload share of final packages (%)", fontsize=7)
    ax.set_ylim(0, 100)
    set_discount_axis(ax)
    ax.text(
        0.03,
        0.94,
        f"late share {late[0]:.2f}% -> {late[-1]:.2f}%",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=6.3,
        color=COLORS["muted"],
    )


def write_caption(main: pd.DataFrame, structure: pd.DataFrame, temporal: pd.DataFrame) -> None:
    first = main.iloc[0]
    peak = main.loc[main["Mitigation value"].idxmax()]
    last = main.iloc[-1]
    capped_count = int((main["Stop"] == "iteration cap").sum())
    status_sentence = (
        f"All {len(main)} runs converged."
        if capped_count == 0
        else f"Filled markers denote converged runs; open markers denote the {capped_count} iteration-cap incumbents."
    )
    text = f"""# Figure 12. Discount-response mechanism in the 934-task case study

The figure summarizes RQ3 using discount-rate sensitivity runs for the expanded
934-task case project with carbon tax and green subsidy fixed at 0.5. **a**, Financial
response trajectory, plotting optimized final project value against mitigation
value; point size indicates mitigation ratio and arrows show the tested
discount-rate sequence. **b**,
Package-structure response, showing average package size and standard deviation
of package size in the optimized final partition. **c**, Temporal workload
reallocation, showing early-, middle-, and late-stage workload shares in the
optimized final package plan. Each point is one case-project run.
{status_sentence} As the discount rate increases from 0 to 0.001, final
value improves from {first['Final value']:,.2f} to {last['Final value']:,.2f},
while absolute mitigation rises from {first['Mitigation value']:,.2f} to
{peak['Mitigation value']:,.2f} at discount rate {format_discount_label(peak['Discount rate'])}
and then declines to {last['Mitigation value']:,.2f}. The package structure
becomes larger and more heterogeneous, with average package size increasing
from {structure['Avg. package size'].iloc[0]:.2f} to
{structure['Avg. package size'].iloc[-1]:.2f} tasks and package-size standard
deviation increasing from {structure['STD package size'].iloc[0]:.2f} to
{structure['STD package size'].iloc[-1]:.2f}. The late-stage workload share
changes from {temporal['Late workload share (%)'].iloc[0]:.2f}% to
{temporal['Late workload share (%)'].iloc[-1]:.2f}%. Lines and filled areas are
descriptive summaries over the tested discount-rate grid and are not
inferential confidence intervals.
"""
    CAPTION_MD.write_text(text, encoding="utf-8")


def write_qa(main: pd.DataFrame, structure: pd.DataFrame, temporal: pd.DataFrame, plot_data: pd.DataFrame) -> None:
    capped = main[main["Stop"] == "iteration cap"]
    text = f"""# QA Note: Case RQ3 Discount Sensitivity Figure

- Backend: Python / matplotlib only.
- Source rows: main={len(main)}, structure={len(structure)}, temporal={len(temporal)}.
- Plot-data rows: {len(plot_data)}.
- Discount-rate grid: {', '.join(DISCOUNT_LABELS)}.
- Iteration-cap rows encoded with open markers: {len(capped)}.
- Iteration-cap discount rates: {', '.join(format_discount_label(v) for v in capped['Discount rate'])}.
- Main and structure tables agree on final packages, average package size, and makespan.
- Rounded mitigation arithmetic verified with tolerance 0.02.
- Temporal workload shares sum to 100% within rounding tolerance.
- Panel a uses only the readability transformation Final value/1000 and Mitigation value/1000.
- Marker size in Panel a is generated monotonically from Mitigation ratio (%).
- SVG text remains editable through matplotlib `svg.fonttype = none`.
- PDF font type is set to TrueType through matplotlib `pdf.fonttype = 42`.
- TIFF export resolution: 600 dpi.
- No fitted curves, inferential intervals, p-values, or post-hoc value edits were added.
"""
    QA_MD.write_text(text, encoding="utf-8")


def save_figure(fig: plt.Figure) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIGURE_STEM.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    fig.savefig(FIGURE_STEM.with_suffix(".png"), dpi=300, bbox_inches="tight")
    preview = FIGURE_STEM.with_name(FIGURE_STEM.name + "_preview").with_suffix(".png")
    fig.savefig(preview, dpi=220, bbox_inches="tight")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    main_df, structure_df, temporal_df = load_and_validate()
    add_common_columns(main_df, structure_df, temporal_df)
    plot_data = build_plot_data(main_df, structure_df, temporal_df)
    plot_data.to_csv(PLOT_DATA_CSV, index=False)
    fig = make_figure(main_df, structure_df, temporal_df)
    save_figure(fig)
    plt.close(fig)
    write_caption(main_df, structure_df, temporal_df)
    write_qa(main_df, structure_df, temporal_df, plot_data)
    print(f"Saved figure bundle to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()

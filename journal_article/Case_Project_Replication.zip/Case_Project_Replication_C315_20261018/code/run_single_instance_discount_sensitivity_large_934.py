﻿from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
CODE_DIR = Path(__file__).resolve().parent
SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE_DIR))
sys.path.insert(0, str(SCRIPT_DIR))

from wp_carbon import PolicyParams, evaluate_partition, load_instance
from revision1_fast_gcmm import run_gcmm_fast as run_micf
from wp_carbon.graph import partition_is_valid

import run_single_instance_detail_large_934 as detail


# =============================================================================
# IDE EDITABLE EXECUTION CONFIGURATION
# =============================================================================

# Specific large case project instance for discount-rate sensitivity analysis.
INSTANCE_FILE_PATH = ROOT / "case" / "polyu_case_project_wp_large_934.rcp"

# Output directory for all discount-rate sensitivity results.
RESULT_OUTPUT_DIR = ROOT / "results" / "single_instance_discount_sensitivity"

# Algorithm configuration. These match run_single_instance_detail.py by default.
INITIALIZATION = "serial_dp"  # "serial_dp" or "atomistic"
MAX_ITERATIONS: int | None = None
IMPROVEMENT_TOLERANCE = 1e-9

# Policy configuration. RQ3 varies only the discount rate.
TAX_RATE = 0.5
SUBSIDY_RATE = 0.5
DISCOUNT_RATES = [0.0, 0.00005, 0.0001, 0.0002, 0.0005, 0.001]
BASELINE_DISCOUNT_RATE = 0.0001

# Valuation model configuration.
TAX_PERIOD = 30.0
SETUP_COST = 20.0
TAX_CONVEXITY = 1.2
SUBSIDY_CONCAVITY = 0.8

# Output controls.
SAVE_PER_DISCOUNT_DETAILS = True
SAVE_ITERATION_HISTORIES = True
SAVE_FINAL_PARTITIONS = True
EXPORT_NETWORK_DIAGRAMS = False
NETWORK_SNAPSHOT_ITERATIONS: str | list[int] = "AUTO"

# Set this to True to regenerate summary tables from existing per-discount
# folders without rerunning the algorithm.
COLLECT_ONLY_FROM_EXISTING_RESULTS = False


def scenario_key(discount_rate: float) -> str:
    return f"discount_{discount_rate:g}".replace(".", "p")


def make_policy(discount_rate: float) -> PolicyParams:
    return PolicyParams(
        tax_rate=TAX_RATE,
        subsidy_rate=SUBSIDY_RATE,
        discount_rate=discount_rate,
        tax_period=TAX_PERIOD,
        setup_cost=SETUP_COST,
        tax_convexity=TAX_CONVEXITY,
        subsidy_concavity=SUBSIDY_CONCAVITY,
    )


def summary_row(
    instance,
    init_partition,
    baseline,
    result,
    policy: PolicyParams,
    runtime_seconds: float,
) -> dict[str, object]:
    final = result.valuation
    mitigation_value = final.total_value - baseline.total_value
    initial_abs_loss = abs(baseline.total_value)
    return {
        "instance": detail.display_path(INSTANCE_FILE_PATH),
        "initialization": INITIALIZATION,
        "tax_rate": policy.tax_rate,
        "subsidy_rate": policy.subsidy_rate,
        "discount_rate": policy.discount_rate,
        "tax_period": policy.tax_period,
        "setup_cost": policy.setup_cost,
        "tax_convexity": policy.tax_convexity,
        "subsidy_concavity": policy.subsidy_concavity,
        "max_iterations": "" if MAX_ITERATIONS is None else MAX_ITERATIONS,
        "stopped_by": result.stopped_by,
        "final_best_delta": result.final_best_delta,
        "final_candidate_count": result.final_candidate_count,
        "iterations": len(result.history) - 1,
        "runtime_seconds": round(runtime_seconds, 6),
        "n_tasks": instance.n_tasks,
        "n_arcs": instance.n_arcs,
        "inactive_tasks": instance.inactive_count,
        "initial_value": baseline.total_value,
        "final_value": final.total_value,
        "mitigation_value": mitigation_value,
        "mitigation_ratio_initial_pct": 100.0 * mitigation_value / initial_abs_loss
        if initial_abs_loss
        else 0.0,
        "initial_packages": len(init_partition),
        "final_packages": len(result.partition),
        "package_reduction": len(init_partition) - len(result.partition),
        "package_reduction_pct": 100.0
        * (len(init_partition) - len(result.partition))
        / len(init_partition),
        "final_average_package_size": sum(len(package) for package in result.partition)
        / len(result.partition),
        "final_makespan": final.makespan,
        "subsidy_pv": final.subsidy_pv,
        "tax_pv": final.tax_pv,
        "setup_pv": final.setup_pv,
        "valid_partition": partition_is_valid(instance, result.partition),
    }


def write_per_discount_outputs(
    instance,
    result,
    policy: PolicyParams,
    scenario_dir: Path,
) -> None:
    scenario_dir.mkdir(parents=True, exist_ok=True)

    if SAVE_ITERATION_HISTORIES:
        history_rows = [
            {
                "instance": detail.display_path(INSTANCE_FILE_PATH),
                "initialization": INITIALIZATION,
                "tax_rate": policy.tax_rate,
                "subsidy_rate": policy.subsidy_rate,
                "discount_rate": policy.discount_rate,
                **asdict(record),
            }
            for record in result.history
        ]
        detail.write_rows(scenario_dir / "iteration_history.csv", history_rows)

    detail.write_rows(
        scenario_dir / "final_work_packages.csv",
        detail.package_summary_rows(instance, result.partition, policy),
    )
    detail.write_rows(
        scenario_dir / "final_task_assignments.csv",
        detail.task_assignment_rows(instance, result.partition, policy),
    )

    if SAVE_FINAL_PARTITIONS:
        partition_json = {
            "instance": detail.display_path(INSTANCE_FILE_PATH),
            "initialization": INITIALIZATION,
            "tax_rate": policy.tax_rate,
            "subsidy_rate": policy.subsidy_rate,
            "discount_rate": policy.discount_rate,
            "final_partition_zero_based": [list(package) for package in result.partition],
            "final_partition_one_based": [
                [task + 1 for task in package] for package in result.partition
            ],
        }
        (scenario_dir / "final_partition.json").write_text(
            json.dumps(partition_json, indent=2), encoding="utf-8"
        )

    if EXPORT_NETWORK_DIAGRAMS:
        original_snapshots = detail.SNAPSHOT_ITERATIONS
        detail.SNAPSHOT_ITERATIONS = NETWORK_SNAPSHOT_ITERATIONS
        try:
            diagrams_dir = scenario_dir / "network_diagrams"
            for idx in detail.select_snapshot_indices(len(result.partition_history)):
                partition = result.partition_history[idx]
                if idx == 0:
                    label = "Initial"
                elif idx == len(result.partition_history) - 1:
                    label = "Final"
                else:
                    label = f"Phase_{idx:03d}"
                detail.export_network_svg(
                    instance=instance,
                    partition=partition,
                    iteration=idx,
                    output_path=diagrams_dir / f"Network_Iter_{idx:03d}_{label}.svg",
                    title=f"Work Package Network Structure, discount={policy.discount_rate:g}",
                )
        finally:
            detail.SNAPSHOT_ITERATIONS = original_snapshots


def run_one_discount(instance, discount_rate: float) -> dict[str, object]:
    policy = make_policy(discount_rate)
    init_partition = detail.initial_partition(instance, INITIALIZATION)
    baseline = evaluate_partition(instance, init_partition, policy)

    start = time.perf_counter()
    result = run_micf(
        instance,
        policy,
        initial_partition=init_partition,
        max_iterations=MAX_ITERATIONS,
        improvement_tolerance=IMPROVEMENT_TOLERANCE,
    )
    runtime_seconds = time.perf_counter() - start

    row = summary_row(instance, init_partition, baseline, result, policy, runtime_seconds)
    if SAVE_PER_DISCOUNT_DETAILS:
        write_per_discount_outputs(
            instance=instance,
            result=result,
            policy=policy,
            scenario_dir=RESULT_OUTPUT_DIR / scenario_key(discount_rate),
        )
    return row


def build_effect_rows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    baseline_rows = [
        row
        for row in rows
        if abs(float(row["discount_rate"]) - BASELINE_DISCOUNT_RATE) < 1e-12
    ]
    if not baseline_rows:
        return []
    baseline = baseline_rows[0]

    effects: list[dict[str, object]] = []
    for row in sorted(rows, key=lambda item: float(item["discount_rate"])):
        effects.append(
            {
                "discount_rate": row["discount_rate"],
                "baseline_discount_rate": BASELINE_DISCOUNT_RATE,
                "mitigation_value": row["mitigation_value"],
                "mitigation_change_vs_baseline": row["mitigation_value"]
                - baseline["mitigation_value"],
                "mitigation_change_pct_vs_baseline": 100.0
                * (row["mitigation_value"] / baseline["mitigation_value"] - 1.0),
                "mitigation_ratio_initial_pct": row["mitigation_ratio_initial_pct"],
                "mitigation_ratio_change_vs_baseline": row[
                    "mitigation_ratio_initial_pct"
                ]
                - baseline["mitigation_ratio_initial_pct"],
                "final_packages": row["final_packages"],
                "final_packages_change_vs_baseline": row["final_packages"]
                - baseline["final_packages"],
                "package_reduction_pct": row["package_reduction_pct"],
                "final_value": row["final_value"],
                "final_value_change_vs_baseline": row["final_value"]
                - baseline["final_value"],
                "subsidy_pv": row["subsidy_pv"],
                "tax_pv": row["tax_pv"],
                "setup_pv": row["setup_pv"],
            }
        )
    return effects


def run_discount_sensitivity() -> None:
    RESULT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    instance = load_instance(INSTANCE_FILE_PATH)

    rows: list[dict[str, object]] = []
    for index, discount_rate in enumerate(DISCOUNT_RATES, start=1):
        print(f"[{index}/{len(DISCOUNT_RATES)}] Running discount rate {discount_rate:g}")
        row = run_one_discount(instance, discount_rate)
        rows.append(row)
        print(
            f"  value={row['initial_value']:.3f} -> {row['final_value']:.3f}; "
            f"mitigation={row['mitigation_value']:.3f}; "
            f"packages={row['initial_packages']} -> {row['final_packages']}; "
            f"stop={row['stopped_by']}"
        )

    rows = sorted(rows, key=lambda item: float(item["discount_rate"]))
    detail.write_rows(RESULT_OUTPUT_DIR / "discount_sensitivity_summary.csv", rows)
    detail.write_rows(
        RESULT_OUTPUT_DIR / "discount_sensitivity_effects.csv",
        build_effect_rows(rows),
    )
    write_readme(rows)
    print(f"Saved discount-rate sensitivity outputs to {RESULT_OUTPUT_DIR}")


def read_summary_rows(path: Path) -> list[dict[str, object]]:
    import csv

    with path.open("r", newline="", encoding="utf-8") as file:
        rows = list(csv.DictReader(file))

    numeric_columns = {
        "discount_rate",
        "mitigation_value",
        "mitigation_ratio_initial_pct",
        "final_packages",
        "package_reduction_pct",
        "final_value",
        "subsidy_pv",
        "tax_pv",
        "setup_pv",
    }
    for row in rows:
        for column in numeric_columns:
            row[column] = float(row[column])
    return rows


def collect_existing_results() -> None:
    summary_path = RESULT_OUTPUT_DIR / "discount_sensitivity_summary.csv"
    if not summary_path.exists():
        raise SystemExit(f"No existing summary found: {summary_path}")
    rows = read_summary_rows(summary_path)
    detail.write_rows(
        RESULT_OUTPUT_DIR / "discount_sensitivity_effects.csv",
        build_effect_rows(rows),
    )
    write_readme(rows)
    print(f"Regenerated discount sensitivity effects from {summary_path}")


def write_readme(rows: list[dict[str, object]]) -> None:
    rates = ", ".join(f"{float(row['discount_rate']):g}" for row in rows)
    lines = [
        "# Case Project Discount-Rate Sensitivity",
        "",
        f"Instance: `{INSTANCE_FILE_PATH}`",
        f"Tax rate: `{TAX_RATE}`",
        f"Subsidy rate: `{SUBSIDY_RATE}`",
        f"Discount rates: `{rates}`",
        "",
        "Files:",
        "",
        "- `discount_sensitivity_summary.csv`: one row per discount rate.",
        "- `discount_sensitivity_effects.csv`: changes relative to "
        f"`BASELINE_DISCOUNT_RATE = {BASELINE_DISCOUNT_RATE}`.",
        "- `discount_*/`: optional per-discount detailed outputs, including final work packages, "
        "task assignments, partitions, and iteration histories.",
        "",
        "Primary RQ3 columns:",
        "",
        "- `mitigation_value`",
        "- `mitigation_ratio_initial_pct`",
        "- `final_packages`",
        "- `package_reduction_pct`",
        "- `final_value`",
        "- `subsidy_pv`, `tax_pv`, and `setup_pv`",
    ]
    (RESULT_OUTPUT_DIR / "discount_sensitivity_readme.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    if COLLECT_ONLY_FROM_EXISTING_RESULTS:
        collect_existing_results()
    else:
        run_discount_sensitivity()


if __name__ == "__main__":
    main()


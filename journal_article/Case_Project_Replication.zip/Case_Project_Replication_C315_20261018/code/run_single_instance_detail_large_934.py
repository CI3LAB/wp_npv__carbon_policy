﻿from __future__ import annotations

import colorsys
import csv
from dataclasses import asdict
import html
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
CODE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE_DIR))

from wp_carbon import PolicyParams, evaluate_partition, load_instance, serial_dp_initial_partition
from revision1_fast_gcmm import run_gcmm_fast as run_micf
from wp_carbon.graph import Partition, atomistic_partition, partition_is_valid
from wp_carbon.schedule import package_schedule

# =============================================================================
# IDE EDITABLE EXECUTION CONFIGURATION
# =============================================================================

# Specific large case project instance to execute.
INSTANCE_FILE_PATH = ROOT / "case" / "polyu_case_project_wp_large_934.rcp"

# Output directory for all detailed single-instance results.
RESULT_OUTPUT_DIR = ROOT / "results" / "single_instance_detail"

# Algorithm configuration.
INITIALIZATION = "serial_dp"  # "serial_dp" or "atomistic"
MAX_ITERATIONS: int | None = None
IMPROVEMENT_TOLERANCE = 1e-9

# Policy and valuation configuration.
POLICY = PolicyParams(
    tax_rate=0.5,
    subsidy_rate=0.5,
    discount_rate=0.0001,
    tax_period=30.0,
    setup_cost=20.0,
    tax_convexity=1.2,
    subsidy_concavity=0.8,
)

# Network diagram configuration.
EXPORT_NETWORK_DIAGRAMS = True
NODE_LABEL_BASE = 0  # Use 0 for zero-based task ids, or 1 for one-based labels.
DIAGRAM_WIDTH_MIN = 1800
DIAGRAM_NODE_RADIUS = 10
DIAGRAM_HEIGHT_MIN = 1000
DIAGRAM_CLUSTER_MARGIN_X = 90
DIAGRAM_CLUSTER_TOP_MARGIN = 90
DIAGRAM_CLUSTER_BOTTOM_MARGIN = 58
DIAGRAM_CLUSTER_WIDTH_PER_SQRT_PACKAGE = 240
DIAGRAM_CLUSTER_HEIGHT_PER_SQRT_PACKAGE = 180
DIAGRAM_CLUSTER_TASK_SPACING = 40
DIAGRAM_CLUSTER_HALO_PADDING = 22
DIAGRAM_CLUSTER_CENTER_PADDING = 36
DIAGRAM_CLUSTER_JITTER_FRACTION = 0.30

# Select diagram phases automatically. For a converged run this exports:
# initial, 25%, 50%, 75%, final. You can replace AUTO with a list, e.g. [0, 5, 20, 50].
SNAPSHOT_ITERATIONS: str | list[int] = "AUTO"


def display_path(path: Path) -> str:
    try:
        return str(path.relative_to(ROOT))
    except ValueError:
        return str(path)


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def initial_partition(instance, mode: str) -> Partition:
    if mode == "atomistic":
        return atomistic_partition(instance)
    if mode == "serial_dp":
        return serial_dp_initial_partition(instance)
    raise ValueError(f"Unknown initialization: {mode}")


def package_id_by_task(partition: Partition) -> dict[int, int]:
    mapping: dict[int, int] = {}
    for package_id, package in enumerate(partition):
        for task in package:
            mapping[task] = package_id
    return mapping


def package_task_offsets(task_count: int) -> list[tuple[float, float]]:
    if task_count <= 1:
        return [(0.0, 0.0)]

    if task_count <= 10:
        radius = DIAGRAM_CLUSTER_TASK_SPACING + max(0, task_count - 2) * 2.0
        return [
            (
                radius * math.cos(-math.pi / 2 + 2 * math.pi * index / task_count),
                radius * math.sin(-math.pi / 2 + 2 * math.pi * index / task_count),
            )
            for index in range(task_count)
        ]

    offsets = [(0.0, 0.0)]
    ring = 1
    while len(offsets) < task_count:
        slots = max(8, ring * 8)
        radius = DIAGRAM_CLUSTER_TASK_SPACING * ring
        for slot in range(slots):
            if len(offsets) >= task_count:
                break
            angle = -math.pi / 2 + 2 * math.pi * slot / slots
            offsets.append((radius * math.cos(angle), radius * math.sin(angle)))
        ring += 1
    return offsets


def package_cluster_radius(task_count: int) -> float:
    offsets = package_task_offsets(task_count)
    farthest_task = max(math.hypot(x, y) for x, y in offsets)
    return farthest_task + DIAGRAM_NODE_RADIUS + DIAGRAM_CLUSTER_HALO_PADDING


def diagram_canvas_size(partition: Partition) -> tuple[int, int]:
    package_count = max(1, len(partition))
    scale = math.sqrt(package_count)
    width = max(
        DIAGRAM_WIDTH_MIN,
        math.ceil(2 * DIAGRAM_CLUSTER_MARGIN_X + scale * DIAGRAM_CLUSTER_WIDTH_PER_SQRT_PACKAGE),
    )
    height = max(
        DIAGRAM_HEIGHT_MIN,
        math.ceil(
            DIAGRAM_CLUSTER_TOP_MARGIN
            + DIAGRAM_CLUSTER_BOTTOM_MARGIN
            + scale * DIAGRAM_CLUSTER_HEIGHT_PER_SQRT_PACKAGE
        ),
    )

    package_radii = [package_cluster_radius(len(package)) for package in partition]
    largest_cluster_cell = max(
        (2 * radius + DIAGRAM_CLUSTER_CENTER_PADDING for radius in package_radii),
        default=2 * DIAGRAM_NODE_RADIUS + DIAGRAM_CLUSTER_CENTER_PADDING,
    )
    drawing_width = width - 2 * DIAGRAM_CLUSTER_MARGIN_X
    drawing_height = height - DIAGRAM_CLUSTER_TOP_MARGIN - DIAGRAM_CLUSTER_BOTTOM_MARGIN
    columns = max(1, math.ceil(math.sqrt(package_count * drawing_width / drawing_height)))
    rows = math.ceil(package_count / columns)
    width = max(width, math.ceil(2 * DIAGRAM_CLUSTER_MARGIN_X + columns * largest_cluster_cell))
    height = max(
        height,
        math.ceil(
            DIAGRAM_CLUSTER_TOP_MARGIN
            + DIAGRAM_CLUSTER_BOTTOM_MARGIN
            + rows * largest_cluster_cell
        ),
    )
    return width, height


def clamp(value: float, lower: float, upper: float) -> float:
    if lower > upper:
        return (lower + upper) / 2
    return max(lower, min(upper, value))


def deterministic_noise(seed: int, salt: int) -> float:
    value = math.sin((seed + 1) * 12.9898 + (salt + 1) * 78.233) * 43758.5453
    return value - math.floor(value)


def coprime_step(value: int) -> int:
    if value <= 2:
        return 1

    step = max(1, round(value * 0.6180339887498948))
    while math.gcd(step, value) != 1:
        step += 1
    return step


def interior_slot_order(total_slots: int) -> list[int]:
    step = coprime_step(total_slots)
    return [(index * step) % total_slots for index in range(total_slots)]


def package_center_positions(
    partition: Partition,
    package_radii: dict[int, float],
    width: int,
    height: int,
) -> dict[int, tuple[float, float]]:
    package_ids = list(range(len(partition)))
    if not package_ids:
        return {}

    drawing_width = width - 2 * DIAGRAM_CLUSTER_MARGIN_X
    drawing_height = height - DIAGRAM_CLUSTER_TOP_MARGIN - DIAGRAM_CLUSTER_BOTTOM_MARGIN
    columns = max(1, math.ceil(math.sqrt(len(package_ids) * drawing_width / drawing_height)))
    rows = math.ceil(len(package_ids) / columns)
    cell_width = drawing_width / columns
    cell_height = drawing_height / rows
    slots = interior_slot_order(rows * columns)
    ordered_packages = sorted(
        package_ids,
        key=lambda package_id: (-package_radii[package_id], min(partition[package_id])),
    )

    centers: dict[int, tuple[float, float]] = {}
    for package_id, slot in zip(ordered_packages, slots):
        row = slot // columns
        column = slot % columns
        radius = package_radii[package_id]
        cell_center_x = DIAGRAM_CLUSTER_MARGIN_X + (column + 0.5) * cell_width
        cell_center_y = DIAGRAM_CLUSTER_TOP_MARGIN + (row + 0.5) * cell_height
        max_jitter_x = max(0.0, cell_width / 2 - radius - DIAGRAM_CLUSTER_CENTER_PADDING / 2)
        max_jitter_y = max(0.0, cell_height / 2 - radius - DIAGRAM_CLUSTER_CENTER_PADDING / 2)
        jitter_x = min(max_jitter_x, cell_width * DIAGRAM_CLUSTER_JITTER_FRACTION)
        jitter_y = min(max_jitter_y, cell_height * DIAGRAM_CLUSTER_JITTER_FRACTION)
        x = cell_center_x + (deterministic_noise(package_id, 0) - 0.5) * 2 * jitter_x
        y = cell_center_y + (deterministic_noise(package_id, 1) - 0.5) * 2 * jitter_y
        centers[package_id] = (
            clamp(
                x,
                DIAGRAM_CLUSTER_MARGIN_X + radius,
                width - DIAGRAM_CLUSTER_MARGIN_X - radius,
            ),
            clamp(
                y,
                DIAGRAM_CLUSTER_TOP_MARGIN + radius,
                height - DIAGRAM_CLUSTER_BOTTOM_MARGIN - radius,
            ),
        )

    return centers


def task_positions(
    instance, partition: Partition
) -> tuple[
    dict[int, tuple[float, float]],
    dict[int, tuple[float, float, float]],
    int,
    int,
]:
    width, height = diagram_canvas_size(partition)
    package_radii = {
        package_id: package_cluster_radius(len(package))
        for package_id, package in enumerate(partition)
    }
    package_centers = package_center_positions(
        partition=partition,
        package_radii=package_radii,
        width=width,
        height=height,
    )

    positions: dict[int, tuple[float, float]] = {}
    package_halos: dict[int, tuple[float, float, float]] = {}
    for package_id, package in enumerate(partition):
        center_x, center_y = package_centers[package_id]
        package_halos[package_id] = (center_x, center_y, package_radii[package_id])
        offsets = package_task_offsets(len(package))
        for task, (offset_x, offset_y) in zip(sorted(package), offsets):
            positions[task] = (center_x + offset_x, center_y + offset_y)

    return positions, package_halos, width, height


def color_for_package(package_id: int) -> str:
    hue = ((package_id * 137.508) % 360) / 360
    saturation = 0.62 + 0.12 * ((package_id // 11) % 2)
    lightness = 0.38 + 0.06 * ((package_id // 7) % 2)
    red, green, blue = colorsys.hls_to_rgb(hue, lightness, saturation)
    return "#{:02x}{:02x}{:02x}".format(
        round(red * 255),
        round(green * 255),
        round(blue * 255),
    )


def select_snapshot_indices(history_len: int) -> list[int]:
    if history_len <= 0:
        return []
    if SNAPSHOT_ITERATIONS != "AUTO":
        requested = [idx for idx in SNAPSHOT_ITERATIONS if 0 <= idx < history_len]
        return sorted(set(requested))

    final_idx = history_len - 1
    indices = {
        0,
        int(round(final_idx * 0.25)),
        int(round(final_idx * 0.50)),
        int(round(final_idx * 0.75)),
        final_idx,
    }
    return sorted(indices)


def svg_marker_def() -> str:
    return (
        '<defs><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" '
        'markerWidth="5" markerHeight="5" orient="auto-start-reverse">'
        '<path d="M 0 0 L 10 5 L 0 10 z" fill="#8b8b8b"/></marker></defs>'
    )


def export_network_svg(
    instance,
    partition: Partition,
    iteration: int,
    output_path: Path,
    title: str,
) -> None:
    positions, package_halos, width, height = task_positions(instance, partition)
    task_to_package = package_id_by_task(partition)

    parts: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">',
        svg_marker_def(),
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="{width / 2:.1f}" y="32" text-anchor="middle" '
        'font-family="Arial" font-size="24" font-weight="700">'
        f"{html.escape(title)}</text>",
        f'<text x="{width / 2:.1f}" y="58" text-anchor="middle" '
        'font-family="Arial" font-size="15" fill="#444">'
        f"Iteration {iteration}; Total WPs: {len(partition)}</text>",
    ]

    for package_id, package in enumerate(partition):
        center_x, center_y, radius = package_halos[package_id]
        color = color_for_package(package_id)
        fill_opacity = 0.14 if len(package) > 1 else 0.035
        stroke_opacity = 0.82 if len(package) > 1 else 0.24
        stroke_width = 2.0 if len(package) > 1 else 0.8
        parts.append(
            f'<circle cx="{center_x:.1f}" cy="{center_y:.1f}" r="{radius:.1f}" '
            f'fill="{color}" fill-opacity="{fill_opacity:.3f}" stroke="{color}" '
            f'stroke-width="{stroke_width:.1f}" stroke-opacity="{stroke_opacity:.2f}"/>'
        )
        if len(package) > 1:
            parts.append(
                f'<text x="{center_x:.1f}" y="{center_y - radius + 15:.1f}" '
                'text-anchor="middle" font-family="Arial" font-size="10" '
                f'font-weight="700" fill="{color}">'
                f"WP{package_id} n={len(package)}</text>"
            )

    for source, successors in enumerate(instance.successors):
        x1, y1 = positions[source]
        source_package = task_to_package[source]
        for target in successors:
            x2, y2 = positions[target]
            target_package = task_to_package[target]
            same_package = source_package == target_package
            stroke = color_for_package(source_package) if same_package else "#8b8b8b"
            stroke_width = 1.5 if same_package else 1.0
            opacity = 0.70 if same_package else 0.36
            dx, dy = x2 - x1, y2 - y1
            length = math.hypot(dx, dy) or 1.0
            shrink = DIAGRAM_NODE_RADIUS + 2
            sx = x1 + dx / length * shrink
            sy = y1 + dy / length * shrink
            tx = x2 - dx / length * shrink
            ty = y2 - dy / length * shrink
            parts.append(
                f'<line x1="{sx:.1f}" y1="{sy:.1f}" x2="{tx:.1f}" y2="{ty:.1f}" '
                f'stroke="{stroke}" stroke-width="{stroke_width:.1f}" '
                f'opacity="{opacity:.2f}" marker-end="url(#arrow)"/>'
            )

    for task in range(instance.n_tasks):
        x, y = positions[task]
        package_id = task_to_package[task]
        fill = color_for_package(package_id)
        stroke = "#111" if not instance.tasks[task].inactive else "#000"
        stroke_width = 1.2 if not instance.tasks[task].inactive else 3.0
        label = str(task + NODE_LABEL_BASE)
        parts.append(
            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{DIAGRAM_NODE_RADIUS}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{stroke_width}"/>'
        )
        parts.append(
            f'<text x="{x:.1f}" y="{y + 4:.1f}" text-anchor="middle" '
            'font-family="Arial" font-size="9" font-weight="700" fill="white">'
            f"{html.escape(label)}</text>"
        )

    parts.append(
        '<text x="24" y="{y}" font-family="Arial" font-size="12" fill="#444">'
        "Colored halo = work package cluster; thick node border = inactive/immutable task</text>".format(
            y=height - 22
        )
    )
    parts.append("</svg>")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(parts), encoding="utf-8")


def package_summary_rows(instance, partition: Partition, params: PolicyParams) -> list[dict[str, object]]:
    durations, starts, finishes, _ = package_schedule(instance, partition)
    rows: list[dict[str, object]] = []
    for package_id, package in enumerate(partition):
        workload = sum(instance.tasks[task].workload for task in package)
        inactive_count = sum(1 for task in package if instance.tasks[task].inactive)
        subsidy_pv = params.subsidy_rate * (workload**params.subsidy_concavity) * math.exp(
            -params.discount_rate * starts[package_id]
        )
        filing_time = math.ceil(finishes[package_id] / params.tax_period) * params.tax_period
        tax_pv = params.tax_rate * (workload**params.tax_convexity) * math.exp(
            -params.discount_rate * filing_time
        )
        setup_pv = params.setup_cost * math.exp(-params.discount_rate * starts[package_id])
        rows.append(
            {
                "package_id": package_id,
                "task_count": len(package),
                "task_ids_zero_based": " ".join(str(task) for task in package),
                "task_ids_one_based": " ".join(str(task + 1) for task in package),
                "workload": workload,
                "duration": durations[package_id],
                "start_time": starts[package_id],
                "finish_time": finishes[package_id],
                "tax_filing_time": filing_time,
                "inactive_task_count": inactive_count,
                "subsidy_pv": subsidy_pv,
                "tax_pv": tax_pv,
                "setup_pv": setup_pv,
                "package_value": subsidy_pv - tax_pv - setup_pv,
            }
        )
    return rows


def task_assignment_rows(instance, partition: Partition, params: PolicyParams) -> list[dict[str, object]]:
    _, starts, finishes, _ = package_schedule(instance, partition)
    task_to_package = package_id_by_task(partition)
    rows: list[dict[str, object]] = []
    for task in range(instance.n_tasks):
        package_id = task_to_package[task]
        task_data = instance.tasks[task]
        rows.append(
            {
                "task_id_zero_based": task,
                "task_id_one_based": task + 1,
                "package_id": package_id,
                "inactive": task_data.inactive,
                "workload": task_data.workload,
                "duration": task_data.duration,
                "package_start_time": starts[package_id],
                "package_finish_time": finishes[package_id],
            }
        )
    return rows


def run_detail() -> None:
    RESULT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    diagrams_dir = RESULT_OUTPUT_DIR / "network_diagrams"

    instance = load_instance(INSTANCE_FILE_PATH)
    init_partition = initial_partition(instance, INITIALIZATION)
    baseline = evaluate_partition(instance, init_partition, POLICY)

    start = time.perf_counter()
    result = run_micf(
        instance,
        POLICY,
        initial_partition=init_partition,
        max_iterations=MAX_ITERATIONS,
        improvement_tolerance=IMPROVEMENT_TOLERANCE,
    )
    runtime_seconds = time.perf_counter() - start
    final = result.valuation

    summary_rows = [
        {
            "instance": display_path(INSTANCE_FILE_PATH),
            "initialization": INITIALIZATION,
            "tax_rate": POLICY.tax_rate,
            "subsidy_rate": POLICY.subsidy_rate,
            "discount_rate": POLICY.discount_rate,
            "tax_period": POLICY.tax_period,
            "setup_cost": POLICY.setup_cost,
            "tax_convexity": POLICY.tax_convexity,
            "subsidy_concavity": POLICY.subsidy_concavity,
            "max_iterations": "" if MAX_ITERATIONS is None else MAX_ITERATIONS,
            "stopped_by": result.stopped_by,
            "final_best_delta": result.final_best_delta,
            "final_candidate_count": result.final_candidate_count,
            "iterations": len(result.history) - 1,
            "runtime_seconds": round(runtime_seconds, 6),
            "n_tasks": instance.n_tasks,
            "n_arcs": instance.n_arcs,
            "inactive_tasks": instance.inactive_count,
            "initial_value": baseline.total_value,
            "final_value": final.total_value,
            "mitigation_value": final.total_value - baseline.total_value,
            "initial_packages": len(init_partition),
            "final_packages": len(result.partition),
            "final_average_package_size": sum(len(package) for package in result.partition)
            / len(result.partition),
            "final_makespan": final.makespan,
            "subsidy_pv": final.subsidy_pv,
            "tax_pv": final.tax_pv,
            "setup_pv": final.setup_pv,
            "valid_partition": partition_is_valid(instance, result.partition),
        }
    ]
    write_rows(RESULT_OUTPUT_DIR / "run_summary.csv", summary_rows)

    history_rows = [
        {
            "instance": display_path(INSTANCE_FILE_PATH),
            "initialization": INITIALIZATION,
            "tax_rate": POLICY.tax_rate,
            "subsidy_rate": POLICY.subsidy_rate,
            "discount_rate": POLICY.discount_rate,
            **asdict(record),
        }
        for record in result.history
    ]
    write_rows(RESULT_OUTPUT_DIR / "iteration_history.csv", history_rows)
    write_rows(
        RESULT_OUTPUT_DIR / "final_work_packages.csv",
        package_summary_rows(instance, result.partition, POLICY),
    )
    write_rows(
        RESULT_OUTPUT_DIR / "final_task_assignments.csv",
        task_assignment_rows(instance, result.partition, POLICY),
    )

    partition_json = {
        "instance": display_path(INSTANCE_FILE_PATH),
        "initialization": INITIALIZATION,
        "final_partition_zero_based": [list(package) for package in result.partition],
        "final_partition_one_based": [[task + 1 for task in package] for package in result.partition],
    }
    (RESULT_OUTPUT_DIR / "final_partition.json").write_text(
        json.dumps(partition_json, indent=2), encoding="utf-8"
    )

    if EXPORT_NETWORK_DIAGRAMS:
        for idx in select_snapshot_indices(len(result.partition_history)):
            partition = result.partition_history[idx]
            if idx == 0:
                label = "Initial"
            elif idx == len(result.partition_history) - 1:
                label = "Final"
            else:
                label = f"Phase_{idx:03d}"
            filename = f"Network_Iter_{idx:03d}_{label}.svg"
            export_network_svg(
                instance=instance,
                partition=partition,
                iteration=idx,
                output_path=diagrams_dir / filename,
                title="Large Case Work Package Network Structure",
            )

    print(f"Instance: {display_path(INSTANCE_FILE_PATH)}")
    print(
        f"Value {baseline.total_value:.3f} -> {final.total_value:.3f}; "
        f"packages {len(init_partition)} -> {len(result.partition)}; "
        f"iterations={len(result.history) - 1}; stop={result.stopped_by}"
    )
    print(f"Saved detailed outputs to {RESULT_OUTPUT_DIR}")


if __name__ == "__main__":
    run_detail()


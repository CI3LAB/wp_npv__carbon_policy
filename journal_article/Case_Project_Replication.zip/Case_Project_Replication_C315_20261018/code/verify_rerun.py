"""Regression, weighted-input and output-schema checks; no full case optimization."""
from pathlib import Path
import csv,importlib,json,math,tempfile
from dataclasses import replace
from wp_carbon import load_instance,PolicyParams,evaluate_partition,serial_dp_initial_partition
from wp_carbon.data import Task,ProjectInstance
from wp_carbon.graph import atomistic_partition,partition_is_valid
from wp_carbon.algorithms.micf import run_micf
from revision1_fast_gcmm import run_gcmm_fast
CODE=Path(__file__).resolve().parent;B=CODE.parent;ROOT=B.parents[2]
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=1e-11,abs_tol=1e-7),(a,b)
new=load_instance(B/'case/polyu_case_project_wp_large_934.rcp')
assert len(new.tasks)==934 and all(t.workload>0 and t.duration>0 for t in new.tasks)
for t in new.tasks:close(t.workload,t.raw_workload*t.carbon_emission_coefficient)
assert new.inactive_count==236
# Unchanged core reproduces stored initial and final values on original input.
old=load_instance(ROOT/'Instances/case_instance/archive_934_before_carbon_20260928/polyu_case_project_wp_large_934.rcp')
archive=B/'revision1_large_case/single_instance_detail'
summary=read(archive/'run_summary.csv')[0]
policy=PolicyParams(**{k:float(summary[k]) for k in ['tax_rate','subsidy_rate','discount_rate','tax_period','setup_cost','tax_convexity','subsidy_concavity']})
part=tuple(tuple(x) for x in json.loads((archive/'final_partition.json').read_text())['final_partition_zero_based'])
v=evaluate_partition(old,part,policy);init=serial_dp_initial_partition(old)
close(evaluate_partition(old,init,policy).total_value,summary['initial_value'])
for k in ['subsidy_pv','tax_pv','setup_pv']:close(getattr(v,k),summary[k])
close(v.total_value,summary['final_value']);assert len(init)==int(summary['initial_packages'])
# Unit coefficients produce the exact same legacy evaluator input; nonunit
# coefficients are applied once and positive singleton tasks are charged.
mini=ProjectInstance(Path('tiny.rcp'),1,(Task(0,True,7.5,1,(1,), 'Admin',7.5,1),Task(1,False,20,2,(2,), 'Steel',10,2),Task(2,False,12,3,(), 'Finish',10,1.2)))
v=evaluate_partition(mini,atomistic_partition(mini),PolicyParams(discount_rate=0))
close(v.tax_pv,.5*sum(x**1.2 for x in [7.5,20,12]));close(v.subsidy_pv,.5*sum(x**.8 for x in [7.5,20,12]));close(v.setup_pv,60)
a=run_gcmm_fast(mini,policy);b=run_micf(mini,policy)
assert a.partition==b.partition;close(a.valuation.total_value,b.valuation.total_value)
assert any(pkg==(0,) for pkg in a.partition)
initial=serial_dp_initial_partition(new);assert partition_is_valid(new,initial)
smoke=run_gcmm_fast(new,policy,initial,max_iterations=1)
assert partition_is_valid(new,smoke.partition)
close(smoke.valuation.total_value,evaluate_partition(new,smoke.partition,policy).total_value)
# Run the full original output pipelines on the tiny instance; compare headers
# with downloaded outputs. No production data/result paths are written here.
with tempfile.TemporaryDirectory(prefix='case_rerun_verify_') as tmp:
 modules=[('detail','run_detail','single_instance_detail'),('policy_sensitivity','run_policy_sensitivity','single_instance_policy_sensitivity'),('discount_sensitivity','run_discount_sensitivity','single_instance_discount_sensitivity')]
 for suffix,entry,folder in modules:
  m=importlib.import_module('run_single_instance_'+suffix+'_large_934')
  m.load_instance=lambda _:mini;m.RESULT_OUTPUT_DIR=Path(tmp)/folder;m.INITIALIZATION='atomistic'
  getattr(m,entry)()
  for p in m.RESULT_OUTPUT_DIR.rglob('*.csv'):
   ref=B/'revision1_large_case'/folder/p.relative_to(m.RESULT_OUTPUT_DIR)
   if ref.exists():assert list(read(p)[0])==list(read(ref)[0]),p
  if suffix=='policy_sensitivity':assert len(read(m.RESULT_OUTPUT_DIR/'policy_sensitivity_summary.csv'))==14
  if suffix=='discount_sensitivity':assert len(read(m.RESULT_OUTPUT_DIR/'discount_sensitivity_summary.csv'))==6
report={'legacy_final_value_reproduced':float(summary['final_value']),'legacy_initial_value_reproduced':float(summary['initial_value']),'weighted_case_tasks':934,'singleton_count':236,'one_merge_case_smoke_value':smoke.valuation.total_value,'tiny_fast_reference_agreement':True,'original_csv_headers_preserved':True,'all_three_tiny_output_pipelines_passed':True,'tiny_output_test_initializer':'atomistic to ensure nonzero baseline mitigation; production remains serial_dp'}
(B/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

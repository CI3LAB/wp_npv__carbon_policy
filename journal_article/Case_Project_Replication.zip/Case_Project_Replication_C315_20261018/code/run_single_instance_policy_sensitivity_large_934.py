﻿from __future__ import annotations

from dataclasses import asdict
import csv
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
CODE_DIR = Path(__file__).resolve().parent
SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE_DIR))
sys.path.insert(0, str(SCRIPT_DIR))

from wp_carbon import PolicyParams, evaluate_partition, load_instance
from revision1_fast_gcmm import run_gcmm_fast as run_micf
from wp_carbon.graph import partition_is_valid

import run_single_instance_detail_large_934 as detail


# =============================================================================
# IDE EDITABLE EXECUTION CONFIGURATION
# =============================================================================

# Specific large case project instance for RQ2 policy sensitivity analysis.
INSTANCE_FILE_PATH = ROOT / "case" / "polyu_case_project_wp_large_934.rcp"

# Output directory for all case-project RQ2 policy sensitivity results.
RESULT_OUTPUT_DIR = ROOT / "results" / "single_instance_policy_sensitivity"

# Algorithm configuration. These match run_single_instance_detail.py by default.
INITIALIZATION = "serial_dp"  # "serial_dp" or "atomistic"
MAX_ITERATIONS: int | None = None
IMPROVEMENT_TOLERANCE = 1e-9

# RQ2 one-factor policy sensitivity configuration.
# 1. Vary subsidy rate while holding carbon tax at FIXED_TAX_RATE_FOR_SUBSIDY_SWEEP.
# 2. Vary carbon tax rate while holding subsidy at FIXED_SUBSIDY_RATE_FOR_TAX_SWEEP.
POLICY_LEVELS = [0.0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0]
FIXED_TAX_RATE_FOR_SUBSIDY_SWEEP = 0.5
FIXED_SUBSIDY_RATE_FOR_TAX_SWEEP = 0.5
BASELINE_TAX_RATE = 0.5
BASELINE_SUBSIDY_RATE = 0.5

# Valuation model configuration.
DISCOUNT_RATE = 0.0001
TAX_PERIOD = 30.0
SETUP_COST = 20.0
TAX_CONVEXITY = 1.2
SUBSIDY_CONCAVITY = 0.8

# Output controls.
SAVE_PER_SCENARIO_DETAILS = True
SAVE_ITERATION_HISTORIES = True
SAVE_FINAL_PARTITIONS = True
EXPORT_NETWORK_DIAGRAMS = False
NETWORK_SNAPSHOT_ITERATIONS: str | list[int] = "AUTO"

# Set this to True to regenerate effects/readme from an existing summary without
# rerunning the algorithm.
COLLECT_ONLY_FROM_EXISTING_RESULTS = False


def scenario_key(sensitivity_dimension: str, tax_rate: float, subsidy_rate: float) -> str:
    clean_dimension = sensitivity_dimension.replace("_rate", "")
    tax_part = f"tax_{tax_rate:g}".replace(".", "p")
    subsidy_part = f"subsidy_{subsidy_rate:g}".replace(".", "p")
    return f"{clean_dimension}_sensitivity_{tax_part}_{subsidy_part}"


def make_policy(tax_rate: float, subsidy_rate: float) -> PolicyParams:
    return PolicyParams(
        tax_rate=tax_rate,
        subsidy_rate=subsidy_rate,
        discount_rate=DISCOUNT_RATE,
        tax_period=TAX_PERIOD,
        setup_cost=SETUP_COST,
        tax_convexity=TAX_CONVEXITY,
        subsidy_concavity=SUBSIDY_CONCAVITY,
    )


def scenario_definitions() -> list[dict[str, object]]:
    scenarios: list[dict[str, object]] = []
    for subsidy_rate in POLICY_LEVELS:
        scenarios.append(
            {
                "sensitivity_dimension": "subsidy_rate",
                "focal_rate": subsidy_rate,
                "fixed_counterpart_dimension": "tax_rate",
                "fixed_counterpart_rate": FIXED_TAX_RATE_FOR_SUBSIDY_SWEEP,
                "tax_rate": FIXED_TAX_RATE_FOR_SUBSIDY_SWEEP,
                "subsidy_rate": subsidy_rate,
            }
        )
    for tax_rate in POLICY_LEVELS:
        scenarios.append(
            {
                "sensitivity_dimension": "tax_rate",
                "focal_rate": tax_rate,
                "fixed_counterpart_dimension": "subsidy_rate",
                "fixed_counterpart_rate": FIXED_SUBSIDY_RATE_FOR_TAX_SWEEP,
                "tax_rate": tax_rate,
                "subsidy_rate": FIXED_SUBSIDY_RATE_FOR_TAX_SWEEP,
            }
        )
    return scenarios


def summary_row(
    instance,
    init_partition,
    baseline,
    result,
    policy: PolicyParams,
    scenario: dict[str, object],
    runtime_seconds: float,
) -> dict[str, object]:
    final = result.valuation
    mitigation_value = final.total_value - baseline.total_value
    initial_abs_loss = abs(baseline.total_value)
    return {
        "instance": detail.display_path(INSTANCE_FILE_PATH),
        "initialization": INITIALIZATION,
        "sensitivity_dimension": scenario["sensitivity_dimension"],
        "focal_rate": scenario["focal_rate"],
        "fixed_counterpart_dimension": scenario["fixed_counterpart_dimension"],
        "fixed_counterpart_rate": scenario["fixed_counterpart_rate"],
        "tax_rate": policy.tax_rate,
        "subsidy_rate": policy.subsidy_rate,
        "discount_rate": policy.discount_rate,
        "tax_period": policy.tax_period,
        "setup_cost": policy.setup_cost,
        "tax_convexity": policy.tax_convexity,
        "subsidy_concavity": policy.subsidy_concavity,
        "max_iterations": "" if MAX_ITERATIONS is None else MAX_ITERATIONS,
        "stopped_by": result.stopped_by,
        "final_best_delta": result.final_best_delta,
        "final_candidate_count": result.final_candidate_count,
        "iterations": len(result.history) - 1,
        "runtime_seconds": round(runtime_seconds, 6),
        "n_tasks": instance.n_tasks,
        "n_arcs": instance.n_arcs,
        "inactive_tasks": instance.inactive_count,
        "initial_value": baseline.total_value,
        "final_value": final.total_value,
        "mitigation_value": mitigation_value,
        "mitigation_ratio_initial_pct": 100.0 * mitigation_value / initial_abs_loss
        if initial_abs_loss
        else 0.0,
        "initial_packages": len(init_partition),
        "final_packages": len(result.partition),
        "package_reduction": len(init_partition) - len(result.partition),
        "package_reduction_pct": 100.0
        * (len(init_partition) - len(result.partition))
        / len(init_partition),
        "final_average_package_size": sum(len(package) for package in result.partition)
        / len(result.partition),
        "final_makespan": final.makespan,
        "subsidy_pv": final.subsidy_pv,
        "tax_pv": final.tax_pv,
        "setup_pv": final.setup_pv,
        "valid_partition": partition_is_valid(instance, result.partition),
    }


def write_per_scenario_outputs(
    instance,
    result,
    policy: PolicyParams,
    scenario: dict[str, object],
    scenario_dir: Path,
) -> None:
    scenario_dir.mkdir(parents=True, exist_ok=True)

    if SAVE_ITERATION_HISTORIES:
        history_rows = [
            {
                "instance": detail.display_path(INSTANCE_FILE_PATH),
                "initialization": INITIALIZATION,
                "sensitivity_dimension": scenario["sensitivity_dimension"],
                "focal_rate": scenario["focal_rate"],
                "fixed_counterpart_dimension": scenario["fixed_counterpart_dimension"],
                "fixed_counterpart_rate": scenario["fixed_counterpart_rate"],
                "tax_rate": policy.tax_rate,
                "subsidy_rate": policy.subsidy_rate,
                "discount_rate": policy.discount_rate,
                **asdict(record),
            }
            for record in result.history
        ]
        detail.write_rows(scenario_dir / "iteration_history.csv", history_rows)

    detail.write_rows(
        scenario_dir / "final_work_packages.csv",
        detail.package_summary_rows(instance, result.partition, policy),
    )
    detail.write_rows(
        scenario_dir / "final_task_assignments.csv",
        detail.task_assignment_rows(instance, result.partition, policy),
    )

    if SAVE_FINAL_PARTITIONS:
        partition_json = {
            "instance": detail.display_path(INSTANCE_FILE_PATH),
            "initialization": INITIALIZATION,
            "sensitivity_dimension": scenario["sensitivity_dimension"],
            "focal_rate": scenario["focal_rate"],
            "fixed_counterpart_dimension": scenario["fixed_counterpart_dimension"],
            "fixed_counterpart_rate": scenario["fixed_counterpart_rate"],
            "tax_rate": policy.tax_rate,
            "subsidy_rate": policy.subsidy_rate,
            "discount_rate": policy.discount_rate,
            "final_partition_zero_based": [list(package) for package in result.partition],
            "final_partition_one_based": [
                [task + 1 for task in package] for package in result.partition
            ],
        }
        (scenario_dir / "final_partition.json").write_text(
            json.dumps(partition_json, indent=2), encoding="utf-8"
        )

    if EXPORT_NETWORK_DIAGRAMS:
        original_snapshots = detail.SNAPSHOT_ITERATIONS
        detail.SNAPSHOT_ITERATIONS = NETWORK_SNAPSHOT_ITERATIONS
        try:
            diagrams_dir = scenario_dir / "network_diagrams"
            for idx in detail.select_snapshot_indices(len(result.partition_history)):
                partition = result.partition_history[idx]
                if idx == 0:
                    label = "Initial"
                elif idx == len(result.partition_history) - 1:
                    label = "Final"
                else:
                    label = f"Phase_{idx:03d}"
                detail.export_network_svg(
                    instance=instance,
                    partition=partition,
                    iteration=idx,
                    output_path=diagrams_dir / f"Network_Iter_{idx:03d}_{label}.svg",
                    title=(
                        "Work Package Network Structure, "
                        f"tax={policy.tax_rate:g}, subsidy={policy.subsidy_rate:g}"
                    ),
                )
        finally:
            detail.SNAPSHOT_ITERATIONS = original_snapshots


def run_one_scenario(instance, scenario: dict[str, object]) -> dict[str, object]:
    tax_rate = float(scenario["tax_rate"])
    subsidy_rate = float(scenario["subsidy_rate"])
    policy = make_policy(tax_rate=tax_rate, subsidy_rate=subsidy_rate)
    init_partition = detail.initial_partition(instance, INITIALIZATION)
    baseline = evaluate_partition(instance, init_partition, policy)

    start = time.perf_counter()
    result = run_micf(
        instance,
        policy,
        initial_partition=init_partition,
        max_iterations=MAX_ITERATIONS,
        improvement_tolerance=IMPROVEMENT_TOLERANCE,
    )
    runtime_seconds = time.perf_counter() - start

    row = summary_row(
        instance=instance,
        init_partition=init_partition,
        baseline=baseline,
        result=result,
        policy=policy,
        scenario=scenario,
        runtime_seconds=runtime_seconds,
    )
    if SAVE_PER_SCENARIO_DETAILS:
        write_per_scenario_outputs(
            instance=instance,
            result=result,
            policy=policy,
            scenario=scenario,
            scenario_dir=RESULT_OUTPUT_DIR
            / scenario_key(str(scenario["sensitivity_dimension"]), tax_rate, subsidy_rate),
        )
    return row


def sort_key(row: dict[str, object]) -> tuple[str, float]:
    return (str(row["sensitivity_dimension"]), float(row["focal_rate"]))


def build_effect_rows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    effects: list[dict[str, object]] = []
    by_dimension: dict[str, list[dict[str, object]]] = {}
    for row in rows:
        by_dimension.setdefault(str(row["sensitivity_dimension"]), []).append(row)

    for dimension, dimension_rows in by_dimension.items():
        baseline_rows = [
            row
            for row in dimension_rows
            if abs(float(row["tax_rate"]) - BASELINE_TAX_RATE) < 1e-12
            and abs(float(row["subsidy_rate"]) - BASELINE_SUBSIDY_RATE) < 1e-12
        ]
        if not baseline_rows:
            continue
        baseline = baseline_rows[0]
        for row in sorted(dimension_rows, key=lambda item: float(item["focal_rate"])):
            effects.append(
                {
                    "sensitivity_dimension": dimension,
                    "focal_rate": row["focal_rate"],
                    "fixed_counterpart_dimension": row["fixed_counterpart_dimension"],
                    "fixed_counterpart_rate": row["fixed_counterpart_rate"],
                    "baseline_tax_rate": BASELINE_TAX_RATE,
                    "baseline_subsidy_rate": BASELINE_SUBSIDY_RATE,
                    "tax_rate": row["tax_rate"],
                    "subsidy_rate": row["subsidy_rate"],
                    "mitigation_value": row["mitigation_value"],
                    "mitigation_change_vs_baseline": row["mitigation_value"]
                    - baseline["mitigation_value"],
                    "mitigation_change_pct_vs_baseline": 100.0
                    * (row["mitigation_value"] / baseline["mitigation_value"] - 1.0),
                    "mitigation_ratio_initial_pct": row["mitigation_ratio_initial_pct"],
                    "mitigation_ratio_change_vs_baseline": row[
                        "mitigation_ratio_initial_pct"
                    ]
                    - baseline["mitigation_ratio_initial_pct"],
                    "final_value": row["final_value"],
                    "final_value_change_vs_baseline": row["final_value"]
                    - baseline["final_value"],
                    "final_packages": row["final_packages"],
                    "final_packages_change_vs_baseline": row["final_packages"]
                    - baseline["final_packages"],
                    "final_average_package_size": row["final_average_package_size"],
                    "average_package_size_change_vs_baseline": row[
                        "final_average_package_size"
                    ]
                    - baseline["final_average_package_size"],
                    "subsidy_pv": row["subsidy_pv"],
                    "tax_pv": row["tax_pv"],
                    "setup_pv": row["setup_pv"],
                }
            )
    return sorted(effects, key=sort_key)


def run_policy_sensitivity() -> None:
    RESULT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    instance = load_instance(INSTANCE_FILE_PATH)
    scenarios = scenario_definitions()

    rows: list[dict[str, object]] = []
    for index, scenario in enumerate(scenarios, start=1):
        print(
            f"[{index}/{len(scenarios)}] Running "
            f"{scenario['sensitivity_dimension']}={float(scenario['focal_rate']):g} "
            f"with {scenario['fixed_counterpart_dimension']}="
            f"{float(scenario['fixed_counterpart_rate']):g}"
        )
        row = run_one_scenario(instance, scenario)
        rows.append(row)
        print(
            f"  value={row['initial_value']:.3f} -> {row['final_value']:.3f}; "
            f"mitigation={row['mitigation_value']:.3f}; "
            f"packages={row['initial_packages']} -> {row['final_packages']}; "
            f"stop={row['stopped_by']}"
        )

    rows = sorted(rows, key=sort_key)
    detail.write_rows(RESULT_OUTPUT_DIR / "policy_sensitivity_summary.csv", rows)
    detail.write_rows(
        RESULT_OUTPUT_DIR / "policy_sensitivity_effects_vs_baseline.csv",
        build_effect_rows(rows),
    )
    write_readme(rows)
    print(f"Saved case RQ2 policy sensitivity outputs to {RESULT_OUTPUT_DIR}")


def read_summary_rows(path: Path) -> list[dict[str, object]]:
    with path.open("r", newline="", encoding="utf-8") as file:
        rows = list(csv.DictReader(file))

    numeric_columns = {
        "focal_rate",
        "fixed_counterpart_rate",
        "tax_rate",
        "subsidy_rate",
        "discount_rate",
        "mitigation_value",
        "mitigation_ratio_initial_pct",
        "final_value",
        "final_packages",
        "final_average_package_size",
        "subsidy_pv",
        "tax_pv",
        "setup_pv",
    }
    for row in rows:
        for column in numeric_columns:
            row[column] = float(row[column])
    return rows


def collect_existing_results() -> None:
    summary_path = RESULT_OUTPUT_DIR / "policy_sensitivity_summary.csv"
    if not summary_path.exists():
        raise SystemExit(f"No existing summary found: {summary_path}")
    rows = read_summary_rows(summary_path)
    detail.write_rows(
        RESULT_OUTPUT_DIR / "policy_sensitivity_effects_vs_baseline.csv",
        build_effect_rows(rows),
    )
    write_readme(rows)
    print(f"Regenerated policy sensitivity effects from {summary_path}")


def write_readme(rows: list[dict[str, object]]) -> None:
    dimensions = sorted({str(row["sensitivity_dimension"]) for row in rows})
    levels = ", ".join(f"{level:g}" for level in POLICY_LEVELS)
    lines = [
        "# Case Project RQ2 Carbon-Tax and Subsidy Sensitivity",
        "",
        f"Instance: `{INSTANCE_FILE_PATH}`",
        f"Policy levels tested for each focal dimension: `{levels}`",
        f"Fixed tax rate for subsidy sweep: `{FIXED_TAX_RATE_FOR_SUBSIDY_SWEEP}`",
        f"Fixed subsidy rate for tax sweep: `{FIXED_SUBSIDY_RATE_FOR_TAX_SWEEP}`",
        f"Discount rate: `{DISCOUNT_RATE}`",
        f"Sensitivity dimensions: `{', '.join(dimensions)}`",
        "",
        "Files:",
        "",
        "- `policy_sensitivity_summary.csv`: one row per RQ2 policy scenario.",
        "- `policy_sensitivity_effects_vs_baseline.csv`: changes relative to "
        f"`tax_rate = {BASELINE_TAX_RATE}` and `subsidy_rate = {BASELINE_SUBSIDY_RATE}`.",
        "- `*_sensitivity_*/`: optional per-scenario detailed outputs, including final work "
        "packages, task assignments, partitions, and iteration histories.",
        "",
        "Primary RQ2 columns:",
        "",
        "- `sensitivity_dimension` and `focal_rate` identify which policy parameter is varied.",
        "- `fixed_counterpart_dimension` and `fixed_counterpart_rate` identify the held policy parameter.",
        "- `mitigation_value` and `mitigation_ratio_initial_pct` measure financial mitigation.",
        "- `final_packages`, `final_average_package_size`, and `package_reduction_pct` describe "
        "the optimized work package structure.",
        "- `subsidy_pv`, `tax_pv`, and `setup_pv` provide the policy cash-flow decomposition.",
    ]
    (RESULT_OUTPUT_DIR / "policy_sensitivity_readme.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    if COLLECT_ONLY_FROM_EXISTING_RESULTS:
        collect_existing_results()
    else:
        run_policy_sensitivity()


if __name__ == "__main__":
    main()


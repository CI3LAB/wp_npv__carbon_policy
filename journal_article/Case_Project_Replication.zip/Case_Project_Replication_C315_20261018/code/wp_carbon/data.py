from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Task:
    """One project activity parsed from the simplified .rcp/.sm instance format."""

    task_id: int
    inactive: bool
    workload: float
    duration: float
    successors: tuple[int, ...]
    work_type: str = ""
    raw_workload: float | None = None
    carbon_emission_coefficient: float = 1.0


@dataclass(frozen=True)
class ProjectInstance:
    """A project DAG with task attributes and immutable-task markers."""

    path: Path
    metadata_value: int
    tasks: tuple[Task, ...]

    @property
    def n_tasks(self) -> int:
        return len(self.tasks)

    @property
    def successors(self) -> tuple[tuple[int, ...], ...]:
        return tuple(task.successors for task in self.tasks)

    @property
    def durations(self) -> tuple[float, ...]:
        return tuple(task.duration for task in self.tasks)

    @property
    def workloads(self) -> tuple[float, ...]:
        return tuple(task.workload for task in self.tasks)

    @property
    def inactive_flags(self) -> tuple[bool, ...]:
        return tuple(task.inactive for task in self.tasks)

    @property
    def n_arcs(self) -> int:
        return sum(len(task.successors) for task in self.tasks)

    @property
    def inactive_count(self) -> int:
        return sum(1 for task in self.tasks if task.inactive)


def _read_token_rows(path: Path) -> list[list[str]]:
    rows: list[list[str]] = []
    for line in path.read_text(errors="ignore").splitlines():
        parts = line.strip().split()
        if not parts:
            continue
        try:
            int(parts[0])
        except ValueError:
            continue
        rows.append(parts)
    return rows


def load_instance(path: str | Path) -> ProjectInstance:
    """Load the project instance format used by the conference code.

    Format:
    - first non-empty line: one metadata integer;
    - each following row: inactive_flag workload duration n_successors successors...
      with an optional trailing free-text work type;
    - successor ids in files are 1-based and are converted to 0-based ids.
    """

    path = Path(path)
    if "# schema: case_rcp_v2;" in path.read_text(encoding="utf-8"):
        return _load_carbon_case_v2(path)
    rows = _read_token_rows(path)
    if not rows:
        raise ValueError(f"No parseable rows found in {path}")

    metadata_value = int(rows[0][0])
    raw_tasks = rows[1:]
    n_tasks = len(raw_tasks)
    tasks: list[Task] = []

    for idx, row in enumerate(raw_tasks):
        numeric_prefix: list[int] = []
        for part in row:
            try:
                numeric_prefix.append(int(part))
            except ValueError:
                break

        if len(numeric_prefix) < 4:
            raise ValueError(f"Task row {idx + 2} in {path} has fewer than 4 fields")

        inactive_flag, workload, duration, n_successors = numeric_prefix[:4]
        raw_successors = numeric_prefix[4 : 4 + n_successors]
        if len(raw_successors) < n_successors:
            raise ValueError(
                f"Task row {idx + 2} in {path} has fewer successor fields than declared"
            )

        work_type_parts = row[4 + n_successors :]
        work_type = " ".join(work_type_parts).replace("_", " ")
        successors = tuple(s - 1 for s in raw_successors if 1 <= s <= n_tasks)

        tasks.append(
            Task(
                task_id=idx,
                inactive=bool(inactive_flag),
                workload=float(workload),
                duration=float(duration),
                successors=successors,
                work_type=work_type,
            )
        )

    return ProjectInstance(path=path, metadata_value=metadata_value, tasks=tuple(tasks))


def list_instance_files(root: str | Path) -> list[Path]:
    root = Path(root)
    files: Iterable[Path] = root.rglob("*")
    return sorted(p for p in files if p.suffix.lower() in {".rcp", ".sm"})


def _load_carbon_case_v2(path: Path) -> ProjectInstance:
    """Map q_i*c_i to the legacy workload field exactly once, at ingestion."""
    from decimal import Decimal
    import math
    lines=[line for line in path.read_text(encoding="utf-8").splitlines() if line.strip() and not line.lstrip().startswith("#")]
    metadata=int(lines[0]);tasks=[];n=len(lines)-1
    for idx,line in enumerate(lines[1:]):
        fields=line.split();flag=int(fields[0]);q=Decimal(fields[1]);c=Decimal(fields[2]);d=float(fields[3]);count=int(fields[4])
        if flag not in (0,1) or not q.is_finite() or not c.is_finite() or q<=0 or not 1<=c<=2 or c*10!=int(c*10) or not math.isfinite(d) or d<=0 or count<0:
            raise ValueError(f"Invalid case attributes at task {idx+1}")
        successors=tuple(int(x)-1 for x in fields[5:5+count])
        if len(successors)!=count or len(set(successors))!=count or any(x<=idx or x>=n for x in successors):
            raise ValueError(f"Invalid forward case arcs at task {idx+1}")
        tasks.append(Task(idx,bool(flag),float(q*c),d,successors," ".join(fields[5+count:]),float(q),float(c)))
    if metadata!=sum(t.inactive for t in tasks):raise ValueError("Singleton count mismatch")
    return ProjectInstance(path,metadata,tuple(tasks))

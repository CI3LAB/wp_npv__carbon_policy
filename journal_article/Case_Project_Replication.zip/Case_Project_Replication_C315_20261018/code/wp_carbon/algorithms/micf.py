from __future__ import annotations

from dataclasses import dataclass

from ..data import ProjectInstance
from ..graph import (
    Partition,
    atomistic_partition,
    feasible_adjacent_merge_indices,
    merge_packages,
    partition_is_valid,
)
from ..valuation import PolicyParams, ValuationResult, evaluate_partition


@dataclass(frozen=True)
class IterationRecord:
    iteration: int
    total_value: float
    num_packages: int
    average_package_size: float
    makespan: float
    subsidy_pv: float
    tax_pv: float
    setup_pv: float
    best_delta: float


@dataclass(frozen=True)
class MICFResult:
    partition: Partition
    valuation: ValuationResult
    history: tuple[IterationRecord, ...]
    partition_history: tuple[Partition, ...]
    stopped_by: str
    final_best_delta: float
    final_candidate_count: int


def _record(
    iteration: int,
    partition: Partition,
    valuation: ValuationResult,
    best_delta: float,
) -> IterationRecord:
    return IterationRecord(
        iteration=iteration,
        total_value=valuation.total_value,
        num_packages=len(partition),
        average_package_size=sum(len(package) for package in partition) / len(partition),
        makespan=valuation.makespan,
        subsidy_pv=valuation.subsidy_pv,
        tax_pv=valuation.tax_pv,
        setup_pv=valuation.setup_pv,
        best_delta=best_delta,
    )


def _best_remaining_delta(
    instance: ProjectInstance, partition: Partition, valuation: ValuationResult, params: PolicyParams
) -> tuple[float, int]:
    best_delta = 0.0
    candidate_count = 0
    for i, j in feasible_adjacent_merge_indices(instance, partition):
        candidate_count += 1
        candidate = merge_packages(partition, i, j)
        candidate_valuation = evaluate_partition(instance, candidate, params)
        delta = candidate_valuation.total_value - valuation.total_value
        if delta > best_delta:
            best_delta = delta
    return best_delta, candidate_count


def run_micf(
    instance: ProjectInstance,
    params: PolicyParams,
    initial_partition: Partition | None = None,
    max_iterations: int | None = None,
    improvement_tolerance: float = 1e-9,
) -> MICFResult:
    """Run adjacency-restricted Myerson-informed coalition formation.

    This implementation only considers adjacent packages whose union remains a
    connected, acyclic, immutable-task-respecting work package partition.
    """

    partition = initial_partition or atomistic_partition(instance)
    if not partition_is_valid(instance, partition):
        raise ValueError("Initial partition is not graph-feasible")

    valuation = evaluate_partition(instance, partition, params)
    history: list[IterationRecord] = [_record(0, partition, valuation, 0.0)]
    partition_history: list[Partition] = [partition]
    iteration = 0

    while max_iterations is None or iteration < max_iterations:
        best_partition: Partition | None = None
        best_valuation: ValuationResult | None = None
        best_delta = 0.0
        candidate_count = 0

        for i, j in feasible_adjacent_merge_indices(instance, partition):
            candidate_count += 1
            candidate = merge_packages(partition, i, j)
            candidate_valuation = evaluate_partition(instance, candidate, params)
            delta = candidate_valuation.total_value - valuation.total_value
            if delta > best_delta:
                best_delta = delta
                best_partition = candidate
                best_valuation = candidate_valuation

        if best_partition is None or best_valuation is None or best_delta <= improvement_tolerance:
            stopped_by = "converged"
            break

        iteration += 1
        partition = best_partition
        valuation = best_valuation
        history.append(_record(iteration, partition, valuation, best_delta))
        partition_history.append(partition)
    else:
        stopped_by = "iteration_cap"
        best_delta, candidate_count = _best_remaining_delta(instance, partition, valuation, params)

    return MICFResult(
        partition=partition,
        valuation=valuation,
        history=tuple(history),
        partition_history=tuple(partition_history),
        stopped_by=stopped_by,
        final_best_delta=best_delta,
        final_candidate_count=candidate_count,
    )

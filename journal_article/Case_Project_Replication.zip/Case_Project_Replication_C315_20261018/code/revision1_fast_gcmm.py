from __future__ import annotations

from collections import deque
import math

from wp_carbon.algorithms.micf import IterationRecord, MICFResult
from wp_carbon.data import ProjectInstance
from wp_carbon.graph import Partition, atomistic_partition, merge_packages, package_successors, partition_is_valid
from wp_carbon.schedule import earliest_start_finish, package_duration
from wp_carbon.valuation import PolicyParams, ValuationResult, evaluate_partition


def _record(
    iteration: int,
    partition: Partition,
    valuation: ValuationResult,
    best_delta: float,
) -> IterationRecord:
    return IterationRecord(
        iteration=iteration,
        total_value=valuation.total_value,
        num_packages=len(partition),
        average_package_size=sum(len(package) for package in partition) / len(partition),
        makespan=valuation.makespan,
        subsidy_pv=valuation.subsidy_pv,
        tax_pv=valuation.tax_pv,
        setup_pv=valuation.setup_pv,
        best_delta=best_delta,
    )


def _package_has_inactive(instance: ProjectInstance, package: tuple[int, ...]) -> bool:
    inactive = instance.inactive_flags
    return any(inactive[task] for task in package)


def _path_exists_excluding_edge(
    successors: tuple[tuple[int, ...], ...],
    start: int,
    target: int,
    skipped_edge: tuple[int, int],
) -> bool:
    queue: deque[int] = deque([start])
    seen = {start}
    while queue:
        current = queue.popleft()
        for successor in successors[current]:
            if (current, successor) == skipped_edge:
                continue
            if successor == target:
                return True
            if successor not in seen:
                seen.add(successor)
                queue.append(successor)
    return False


def _fast_feasible_adjacent_merge_indices_from_graph(
    instance: ProjectInstance,
    partition: Partition,
    package_graph: tuple[tuple[int, ...], ...],
) -> list[tuple[int, int]]:
    """Return the same adjacent feasible merge pairs using a DAG contraction test.

    The original implementation validates every candidate by rebuilding the
    full candidate work package scheme. For large case instances, this is the
    dominant runtime cost. This function uses an equivalent condition on the
    current acyclic package graph: contracting an adjacent pair is infeasible
    only when the edge being contracted also has an alternative directed path
    between the two packages, which would become a directed cycle after
    contraction. Existing package connectedness is preserved because candidates
    are adjacent, and inactive-task boundaries are checked explicitly.
    """

    candidate_pairs: set[tuple[int, int]] = set()
    for source, successors in enumerate(package_graph):
        for target in successors:
            candidate_pairs.add(tuple(sorted((source, target))))

    pairs: list[tuple[int, int]] = []
    for i, j in sorted(candidate_pairs):
        if _package_has_inactive(instance, partition[i]):
            continue
        if _package_has_inactive(instance, partition[j]):
            continue

        creates_cycle = False
        if j in package_graph[i] and _path_exists_excluding_edge(package_graph, i, j, (i, j)):
            creates_cycle = True
        if i in package_graph[j] and _path_exists_excluding_edge(package_graph, j, i, (j, i)):
            creates_cycle = True
        if not creates_cycle:
            pairs.append((i, j))
    return pairs


def fast_feasible_adjacent_merge_indices(
    instance: ProjectInstance, partition: Partition
) -> list[tuple[int, int]]:
    return _fast_feasible_adjacent_merge_indices_from_graph(
        instance=instance,
        partition=partition,
        package_graph=package_successors(instance, partition),
    )


def _package_workload(instance: ProjectInstance, package: tuple[int, ...]) -> float:
    return sum(instance.tasks[task].workload for task in package)


def _contract_package_graph(
    package_graph: tuple[tuple[int, ...], ...],
    idx_a: int,
    idx_b: int,
) -> tuple[tuple[int, ...], ...]:
    n_packages = len(package_graph)
    merged_idx = n_packages - 2
    old_to_new: list[int] = [-1] * n_packages
    next_idx = 0
    for old_idx in range(n_packages):
        if old_idx in {idx_a, idx_b}:
            continue
        old_to_new[old_idx] = next_idx
        next_idx += 1
    old_to_new[idx_a] = merged_idx
    old_to_new[idx_b] = merged_idx

    contracted: list[set[int]] = [set() for _ in range(n_packages - 1)]
    for source, successors in enumerate(package_graph):
        new_source = old_to_new[source]
        for target in successors:
            new_target = old_to_new[target]
            if new_source != new_target:
                contracted[new_source].add(new_target)
    return tuple(tuple(sorted(items)) for items in contracted)


def _candidate_state(
    instance: ProjectInstance,
    partition: Partition,
    package_graph: tuple[tuple[int, ...], ...],
    package_durations: tuple[float, ...],
    package_workloads: tuple[float, ...],
    idx_a: int,
    idx_b: int,
    duration_cache: dict[tuple[int, ...], float],
) -> tuple[Partition, tuple[float, ...], tuple[float, ...], tuple[tuple[int, ...], ...]]:
    merged_package = tuple(sorted(partition[idx_a] + partition[idx_b]))
    if merged_package not in duration_cache:
        duration_cache[merged_package] = package_duration(instance, merged_package)
    merged_duration = duration_cache[merged_package]
    merged_workload = package_workloads[idx_a] + package_workloads[idx_b]

    keep_indices = [idx for idx in range(len(partition)) if idx not in {idx_a, idx_b}]
    candidate_partition = tuple(partition[idx] for idx in keep_indices) + (merged_package,)
    candidate_durations = tuple(package_durations[idx] for idx in keep_indices) + (merged_duration,)
    candidate_workloads = tuple(package_workloads[idx] for idx in keep_indices) + (merged_workload,)
    candidate_graph = _contract_package_graph(package_graph, idx_a, idx_b)
    return candidate_partition, candidate_durations, candidate_workloads, candidate_graph


def _evaluate_from_state(
    durations: tuple[float, ...],
    workloads: tuple[float, ...],
    successors: tuple[tuple[int, ...], ...],
    params: PolicyParams,
) -> ValuationResult:
    starts, finishes, makespan = earliest_start_finish(durations, successors)
    subsidy_pv = 0.0
    tax_pv = 0.0
    setup_pv = 0.0
    for workload, start, finish in zip(workloads, starts, finishes):
        subsidy_pv += (
            params.subsidy_rate
            * (workload**params.subsidy_concavity)
            * math.exp(-params.discount_rate * start)
        )
        filing_time = math.ceil(finish / params.tax_period) * params.tax_period
        tax_pv += (
            params.tax_rate
            * (workload**params.tax_convexity)
            * math.exp(-params.discount_rate * filing_time)
        )
        setup_pv += params.setup_cost * math.exp(-params.discount_rate * start)
    return ValuationResult(
        total_value=subsidy_pv - tax_pv - setup_pv,
        makespan=makespan,
        subsidy_pv=subsidy_pv,
        tax_pv=tax_pv,
        setup_pv=setup_pv,
        package_durations=durations,
        package_start_times=starts,
        package_finish_times=finishes,
    )


def _best_remaining_delta(
    instance: ProjectInstance,
    partition: Partition,
    valuation: ValuationResult,
    params: PolicyParams,
    duration_cache: dict[tuple[int, ...], float] | None = None,
) -> tuple[float, int]:
    best_delta = 0.0
    candidate_count = 0
    package_graph = package_successors(instance, partition)
    package_durations = tuple(duration_cache.get(package, package_duration(instance, package)) for package in partition) if duration_cache else tuple(package_duration(instance, package) for package in partition)
    package_workloads = tuple(_package_workload(instance, package) for package in partition)
    duration_cache = duration_cache if duration_cache is not None else {}
    for i, j in _fast_feasible_adjacent_merge_indices_from_graph(instance, partition, package_graph):
        candidate_count += 1
        _, candidate_durations, candidate_workloads, candidate_graph = _candidate_state(
            instance=instance,
            partition=partition,
            package_graph=package_graph,
            package_durations=package_durations,
            package_workloads=package_workloads,
            idx_a=i,
            idx_b=j,
            duration_cache=duration_cache,
        )
        candidate_valuation = _evaluate_from_state(
            candidate_durations, candidate_workloads, candidate_graph, params
        )
        delta = candidate_valuation.total_value - valuation.total_value
        if delta > best_delta:
            best_delta = delta
    return best_delta, candidate_count


def run_gcmm_fast(
    instance: ProjectInstance,
    params: PolicyParams,
    initial_partition: Partition | None = None,
    max_iterations: int | None = None,
    improvement_tolerance: float = 1e-9,
) -> MICFResult:
    """Run GCMM with an equivalent large-case candidate-generation shortcut."""

    partition = initial_partition or atomistic_partition(instance)
    # The provided initial schemes come from atomistic_partition or
    # serial_dp_initial_partition, both of which already guarantee feasibility.
    # Re-running partition_is_valid for every 934-task policy scenario is a
    # duplicate full-graph validation and dominates local case-study runtime.

    valuation = evaluate_partition(instance, partition, params)
    history: list[IterationRecord] = [_record(0, partition, valuation, 0.0)]
    partition_history: list[Partition] = [partition]
    iteration = 0
    duration_cache: dict[tuple[int, ...], float] = {
        package: package_duration(instance, package) for package in partition
    }

    while max_iterations is None or iteration < max_iterations:
        best_partition: Partition | None = None
        best_valuation: ValuationResult | None = None
        best_delta = 0.0
        candidate_count = 0
        package_graph = package_successors(instance, partition)
        package_durations = tuple(duration_cache[package] for package in partition)
        package_workloads = tuple(_package_workload(instance, package) for package in partition)

        for i, j in _fast_feasible_adjacent_merge_indices_from_graph(
            instance, partition, package_graph
        ):
            candidate_count += 1
            candidate, candidate_durations, candidate_workloads, candidate_graph = _candidate_state(
                instance=instance,
                partition=partition,
                package_graph=package_graph,
                package_durations=package_durations,
                package_workloads=package_workloads,
                idx_a=i,
                idx_b=j,
                duration_cache=duration_cache,
            )
            candidate_valuation = _evaluate_from_state(
                candidate_durations, candidate_workloads, candidate_graph, params
            )
            delta = candidate_valuation.total_value - valuation.total_value
            if delta > best_delta:
                best_delta = delta
                best_partition = candidate
                best_valuation = candidate_valuation

        if best_partition is None or best_valuation is None or best_delta <= improvement_tolerance:
            stopped_by = "converged"
            break

        iteration += 1
        partition = best_partition
        valuation = best_valuation
        history.append(_record(iteration, partition, valuation, best_delta))
        partition_history.append(partition)
    else:
        stopped_by = "iteration_cap"
        best_delta, candidate_count = _best_remaining_delta(
            instance, partition, valuation, params, duration_cache
        )

    return MICFResult(
        partition=partition,
        valuation=valuation,
        history=tuple(history),
        partition_history=tuple(partition_history),
        stopped_by=stopped_by,
        final_best_delta=best_delta,
        final_candidate_count=candidate_count,
    )

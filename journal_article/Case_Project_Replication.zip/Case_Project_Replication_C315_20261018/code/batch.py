"""Prepare, run and inspect three original case pipelines; no algorithm changes."""
from pathlib import Path
import argparse,csv,hashlib,importlib,json,os,platform,sys,time,traceback,uuid
CODE=Path(__file__).resolve().parent;ROOT=CODE.parent
TASKS={'detail':('run_single_instance_detail_large_934','single_instance_detail','run_detail'),
       'policy':('run_single_instance_policy_sensitivity_large_934','single_instance_policy_sensitivity','run_policy_sensitivity'),
       'discount':('run_single_instance_discount_sensitivity_large_934','single_instance_discount_sensitivity','run_discount_sensitivity')}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2),encoding='utf-8');os.replace(tmp,p)
def prepare():
 from wp_carbon import load_instance
 case=ROOT/'case/polyu_case_project_wp_large_934.rcp'
 if '# schema: case_rcp_v2;' not in case.read_text():raise ValueError('Updated case_rcp_v2 required')
 inst=load_instance(case)
 assert (inst.n_tasks,inst.n_arcs,inst.inactive_count)==(934,1261,236)
 with (case.with_name(case.stem+'_mapping.csv')).open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
 assert len(rows)==934
 for t,r in zip(inst.tasks,rows):
  assert t.task_id+1==int(r['new_task_id']) and t.workload==float(r['carbon_weighted_workload'])
  assert t.raw_workload==float(r['workload']) and t.duration==float(r['standard_duration'])
  assert t.carbon_emission_coefficient==float(r['carbon_emission_coefficient'])
 batch=ROOT/'results'/('carbon_case_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
 batch.mkdir(parents=True);(batch/'logs').mkdir();(batch/'status').mkdir()
 manifest={'schema':'carbon_case_rerun_v1','created':time.strftime('%Y-%m-%d %H:%M:%S'),
  'case':str(case.resolve()),'case_sha256':sha(case),'code_sha256':{str(p.relative_to(CODE)).replace('\\','/'):sha(p) for p in CODE.rglob('*.py')},
  'tasks':list(TASKS),'scheduler_jobs':3,'max_parallel_jobs':60,'gcmm_runs':21,
  'initialization':'serial_dp','max_iterations':None,'time_limit_seconds':None,
  'workload_semantics':'q_i * coefficient_i, applied once at loading to all legacy workload uses (initializer, subsidy and tax); durations unscaled',
  'task_count':934,'singleton_tasks':236,'raw_workload_sum':sum(t.raw_workload for t in inst.tasks),'weighted_workload_sum':sum(inst.workloads)}
 write(batch/'manifest.json',manifest)
 with (batch/'task_carbon_inputs.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(['task_id_one_based','inactive','raw_workload','carbon_emission_coefficient','effective_workload','duration'])
  for t in inst.tasks:w.writerow([t.task_id+1,int(t.inactive),t.raw_workload,t.carbon_emission_coefficient,t.workload,t.duration])
 print(batch.resolve())
def run(batch,task):
 batch=batch.resolve();m=json.loads((batch/'manifest.json').read_text());case=Path(m['case'])
 if sha(case)!=m['case_sha256']:raise ValueError('Case changed after preparation')
 for name,h in m['code_sha256'].items():
  if sha(CODE/name)!=h:raise ValueError('Code changed after preparation: '+name)
 # Permanent per-task claim prevents two jobs overwriting the same output.
 claim=batch/'status'/(task+'.claim');claim.mkdir()
 st=batch/'status'/(task+'.json');start=time.time()
 write(st,{'state':'RUNNING','task':task,'pid':os.getpid(),'host':platform.node(),'started':start})
 try:
  name,folder,entry=TASKS[task];mod=importlib.import_module(name)
  mod.INSTANCE_FILE_PATH=case;mod.RESULT_OUTPUT_DIR=batch/folder
  if mod.MAX_ITERATIONS is not None or mod.INITIALIZATION!='serial_dp':raise ValueError('Original stopping/initialization changed')
  getattr(mod,entry)()
  # Validate all stored final partitions without rerunning optimization.
  from wp_carbon import load_instance
  from wp_carbon.graph import partition_is_valid
  inst=load_instance(case);parts=list((batch/folder).rglob('final_partition.json'))
  expected={'detail':1,'policy':14,'discount':6}[task]
  assert len(parts)==expected,(len(parts),expected)
  for p in parts:
   part=json.loads(p.read_text())['final_partition_zero_based']
   assert partition_is_valid(inst,tuple(tuple(x) for x in part))
   assert all(len(pkg)==1 for pkg in part if any(inst.tasks[t].inactive for t in pkg))
  write(st,{'state':'COMPLETE','task':task,'elapsed_seconds':time.time()-start,'partitions_validated':len(parts),'python':sys.version,'host':platform.node()})
 except BaseException:
  write(st,{'state':'FAILED','task':task,'elapsed_seconds':time.time()-start,'traceback':traceback.format_exc()});raise
def status(batch):
 states={t:json.loads(p.read_text()) if (p:=batch/'status'/(t+'.json')).exists() else {'state':'NOT_STARTED'} for t in TASKS}
 print(json.dumps(states,indent=2));return 0 if all(s['state']=='COMPLETE' for s in states.values()) else 1
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);sp=p.add_subparsers(dest='action',required=True)
 sp.add_parser('prepare');r=sp.add_parser('run');r.add_argument('--batch',type=Path,required=True);r.add_argument('--task',choices=TASKS,required=True)
 s=sp.add_parser('status');s.add_argument('--batch',type=Path,required=True)
 a=p.parse_args()
 if a.action=='prepare':prepare()
 elif a.action=='run':run(a.batch,a.task)
 else:sys.exit(status(a.batch))

# Replication scope and remaining records

This folder supports inspection of the adapted case, validation and re-evaluation of all 21 saved final partitions, optional reruns through the unchanged numerical code, and redrawing from the packaged plotting inputs. It does not reconstruct realized project execution, an empirical carbon inventory or an observed before/after financial intervention.

The original case conversion script, complete omitted-edge log and complete field-level calibration are unavailable. Source records and identifying mappings are not distributed. Author clarification of the erroneous initial zero entries is distinguished from independent verification of source measurements.

The folder is case-specific. Raw synthetic-network benchmark experiments are not included. Their separate overall index records the unavailable original generator/generation seeds and the 50 local J160 input discrepancies. Those disclosures and the benchmark's candidate-pool, timing, discount and filing qualifications remain in their existing study records; this case folder does not supersede them.

The original algorithm modules match the recorded execution hashes, and saved observations are copied unchanged. Portable wrappers are new file-location adapters. Runtimes and exported image bytes may differ across machines; compare inputs, objective values, feasibility, schedule and numerical plot data separately.

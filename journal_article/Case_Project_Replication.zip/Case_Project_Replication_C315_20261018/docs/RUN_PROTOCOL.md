# Run protocol and recorded settings

There are 21 saved runs: one representative run, 14 one-factor policy runs and six discount-rate runs. The two policy sweeps both include the common baseline, and the discount design also includes it. These are scenario observations on one network, not independent projects.

All case runs use default Serial-DP followed by merge-only GCMM with improvement tolerance 1e-9, no iteration cap and no time cap. They stop when no improving feasible adjacent merger remains. `config/scenarios.json` identifies each saved summary row, partition, assignment table and history, along with all objective parameters. The default, conservative and aggressive auxiliary initializer values are retained in `config/initializer_variants.json`; only the default is used for these case runs.

The representative policy is alpha = beta = 0.5, r = 0.0001, L = 30, c = 20, eta = 0.8 and gamma = 1.2. Policy sweeps use 0, 0.2, 0.4, 0.5, 0.6, 0.8 and 1.0 for the varying coefficient, keeping the other at 0.5. Discount rates are 0, 0.00005, 0.0001, 0.0002, 0.0005 and 0.001, with alpha = beta = 0.5. The final two rates are stress tests in the revised interpretation.

The archived code uses Python's standard library; the captured Python build is recorded in `metadata/recorded_environment.json`. Case optimization and initialization are deterministic for fixed inputs, so an optimization random seed is not applicable. The figure-redrawing step additionally requires NumPy, pandas and Matplotlib. Their historical versions are not recovered by this package; fonts and rendering environments may affect image bytes.

The 14 execution-code hashes match the original manifest. `scripts/rerun_case.py` redirects paths while retaining those original modules and their constants. It saves new results separately. `code/batch.py` and `code/verify_rerun.py` are retained as execution-history evidence and refer to historical project layouts; they are not the supported portable entry points.

Case runtime is the runtime recorded by the original case pipeline. The elapsed time for its batch wrapper is a different quantity and is recorded separately. Neither should be substituted for the benchmark timing conventions. The study-wide MIP settings in `config/benchmark_protocol_reference.json` supply context for Comment 3.15 and do not describe a MIP run on this 934-task case.

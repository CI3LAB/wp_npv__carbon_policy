# Preparing the later GitHub upload

1. Review this folder's contents and confirm the right to distribute the adapted numerical data and copied code. Source PDFs and identifying mappings are intentionally outside the folder. Set an appropriate license only after confirming ownership and permissions; no license has been inferred here.
2. Run `python scripts/verify_saved_results.py`. Retain its output as an upload check. Optionally run the plotting-data check and a new full rerun, keeping generated outputs separate from the archive.
3. Copy this entire folder to the chosen repository location, keeping its internal paths. Do not upload the parent revision packet, its author-only process folder or identifying source mappings by accident.
4. Review the staged file list, then commit and upload using the authors' normal GitHub workflow. No remote command has been executed during package preparation.
5. Create a versioned tag or release and record the actual repository URL, path and commit/release identifier. Update the manuscript's short availability reference and the response letter accordingly. Until then, state that the folder has been prepared for later deposition.
6. If files are revised, retain the prior release, update the version/change record and regenerate `manifest.json` fingerprints. Preserve historical execution manifests and original archived results.

Large TIFF and high-resolution network PNG duplicates are omitted. Editable SVG and PDF copies, normal-size main-figure PNG previews and exact plot data are supplied. File sizes are recorded in the manifest; review the repository's storage policy if adding the omitted raster exports later.

# Data dictionary and index conventions

- `input/polyu_case_project_wp_large_934.rcp`: the leading 236 is the inactive-task count. After the schema line, each of 934 task rows contains inactive flag, raw workload, relative coefficient, duration, successor count, successor IDs and generic work category. Row position defines a one-based task ID; successor IDs are one-based.
- `input/task_carbon_inputs.csv`: one-based task ID, inactive flag, raw workload, coefficient, effective workload and duration. The coefficient is applied once by the loader.
- `input/task_metadata.csv`: numerical task ID, inactive flag, raw workload, duration, coefficient, effective workload, work type and successor list. Original names, source IDs, WBS and dates are omitted.
- `final_partition.json`: zero-based and one-based task partitions, explicitly named in their keys.
- `final_task_assignments.csv`: zero- and one-based task IDs, local package ID, activity attributes and package schedule. Package IDs are local to that run.
- `final_work_packages.csv`: package membership, workload, duration, start, finish, filing time and subsidy/tax/setup present values.
- `iteration_history.csv`: state 0 is the generated initialization; subsequent rows are accepted mergers. Fields include modeled value, package count, makespan and component present values.
- `data/snapshot_task_to_package.csv`: task membership for the displayed iterations. See the column headers for explicit indexing.
- `data/displayed_snapshot_history.csv`: objective, package structure and makespan at the five displayed states.
- `metadata/display_run_index.csv`: each Figure 10–12 or S3–S7 and the saved scenario or iteration it uses.

Value gain is final value minus the initialized value under the same parameters. The reported percentage uses the absolute initialized value. It describes improvement from the generated reference. Category multi-task coverage uses tasks as its denominator; package shares use packages. The complete category and package-size tables accompany the plot data.

"""Redraw Figures 10-12 with archived drawing functions and packaged tables."""
from pathlib import Path
import argparse,importlib.util,sys

ROOT=Path(__file__).resolve().parents[1]
sys.dont_write_bytecode=True
def load(n):
    filename=f'run_make_nature_case_rq{n}_'+{1:'work_package_mitigation',2:'policy_sensitivity',3:'discount_sensitivity'}[n]+'_figure.py'
    path=ROOT/'analysis/archive'/filename
    spec=importlib.util.spec_from_file_location('case_plot_'+str(n),path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def configure(m,n,out):
    m.OUTPUT_DIR=out;m.FIGURE_STEM=out/f'Figure{n+9}'
    m.PLOT_DATA_CSV=out/f'Figure{n+9}_plot_data.csv'
    m.CAPTION_MD=out/f'Figure{n+9}_caption.md';m.QA_MD=out/f'Figure{n+9}_qa.md'
    if n==1:
        m.DIST_CSV=ROOT/'data/figure10_distribution.csv';m.SUMMARY_CSV=ROOT/'data/case_rq1_summary.csv'
    elif n==2:
        m.MAIN_CSV=m.MAIN_EFFECTS_CSV=m.STRUCTURE_CSV=ROOT/'data/case_rq2_policy_response.csv'
    else:
        m.MAIN_CSV=ROOT/'data/case_rq3_discount_response.csv'
        m.RAW_RESULT_DIR=ROOT/'results/archived/single_instance_discount_sensitivity'
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path,default=ROOT/'redrawn_figures');p.add_argument('--check-data',action='store_true')
    a=p.parse_args();out=a.output_dir.resolve()
    for name in ['figures','data','results','input','code','metadata','analysis','scripts','config','docs']:
        protected=(ROOT/name).resolve()
        if out==protected or protected in out.parents:raise ValueError('Choose a new figure output location.')
    modules=[load(n) for n in [1,2,3]]
    for n,m in enumerate(modules,1):
        configure(m,n,out);m.load_and_validate()
    if a.check_data:
        print('All three archived plotting modules imported and validated the packaged data. No figures or optimization results were generated.');return
    out.mkdir(parents=True,exist_ok=True)
    if list(out.iterdir()):raise FileExistsError('Choose an empty output directory.')
    for n,m in enumerate(modules,1):
        if n!=1:m.main();continue
        # The C38 display correction changes labels and cumulative task coverage only.
        dist,summary=m.load_and_validate();dist=m.augment_distribution(dist,summary);metrics=m.compute_summary_metrics(dist,summary)
        data=m.build_plot_data(dist,summary,metrics);data.to_csv(m.PLOT_DATA_CSV,index=False)
        fig=m.make_figure(dist,summary,metrics);ax,b,c=fig.axes[:3]
        ax.set_title('Final package-size distribution',loc='left',fontsize=8,pad=7)
        for _,r in dist.iterrows():
            if r['Package size']>4:ax.text(r['Package size'],r['Share (%)']+2.1,str(int(r['Package count'])),ha='center',va='bottom',fontsize=6.2,color=m.COLORS['text'])
        fig.texts[0].set_text('Case RQ1: work-package structure and value gain in the 934-task project')
        c.set_title('Modeled-value improvement',loc='left',fontsize=8,pad=7);c.set_ylabel('Modeled value (× 1,000)',fontsize=7)
        for x in [b,c]:x.set_xticklabels(['Initialized','Final'])
        m.save_figure(fig);m.plt.close(fig)
    print('Redrawn Figures 10-12 saved to '+str(out))
if __name__=='__main__':main()

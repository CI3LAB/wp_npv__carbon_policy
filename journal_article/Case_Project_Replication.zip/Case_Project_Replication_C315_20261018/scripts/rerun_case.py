"""Run the archived, unchanged case pipelines into a new results directory."""
from pathlib import Path
import argparse,hashlib,importlib,json,platform,sys,time

ROOT=Path(__file__).resolve().parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'code'))
TASKS={'detail':('run_single_instance_detail_large_934','run_detail','single_instance_detail'),
       'policy':('run_single_instance_policy_sensitivity_large_934','run_policy_sensitivity','single_instance_policy_sensitivity'),
       'discount':('run_single_instance_discount_sensitivity_large_934','run_discount_sensitivity','single_instance_discount_sensitivity')}
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--task',choices=[*TASKS,'all'],default='detail')
    p.add_argument('--output-dir',type=Path,default=ROOT/'rerun_outputs')
    p.add_argument('--list',action='store_true',help='Print the recorded scenario configuration without running optimization.')
    args=p.parse_args()
    if args.list:
        print((ROOT/'config/scenarios.json').read_text(encoding='utf-8'));return
    manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    for r in manifest['files']:
        if r['path'].startswith(('code/','input/')):
            assert hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256'],r['path']
    output=args.output_dir.resolve()
    for folder in ['results','input','code','data','figures','metadata','config','docs','scripts']:
        protected=(ROOT/folder).resolve()
        if output==protected or protected in output.parents:raise ValueError('Choose a new output location outside the packaged evidence.')
    selected=list(TASKS) if args.task=='all' else [args.task]
    for task in selected:
        name,entry,folder=TASKS[task];dest=output/folder
        if dest.exists():raise FileExistsError('Refusing to overwrite '+str(dest))
    output.mkdir(parents=True,exist_ok=True)
    for task in selected:
        name,entry,folder=TASKS[task];module=importlib.import_module(name)
        module.INSTANCE_FILE_PATH=ROOT/'input/polyu_case_project_wp_large_934.rcp'
        module.RESULT_OUTPUT_DIR=output/folder
        assert module.INITIALIZATION=='serial_dp' and module.MAX_ITERATIONS is None
        assert module.IMPROVEMENT_TOLERANCE==1e-9
        started=time.time();getattr(module,entry)()
        record=dict(task=task,elapsed_seconds=time.time()-started,python=sys.version,platform=platform.platform(),package_version=manifest['version'],input_sha256=manifest['input_sha256'],note='Original algorithm and scenario constants retained; only input/output paths are redirected.')
        (output/(task+'_execution.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
if __name__=='__main__':main()

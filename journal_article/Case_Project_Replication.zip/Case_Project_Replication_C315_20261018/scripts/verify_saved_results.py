"""Check the packaged case input, code and all 21 saved final partitions."""
from pathlib import Path
import csv,hashlib,json,math,sys

ROOT=Path(__file__).resolve().parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'code'))
from wp_carbon import load_instance,PolicyParams,evaluate_partition
from wp_carbon.graph import partition_is_valid

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def rows(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def close(a,b):
    if not math.isclose(float(a),float(b),rel_tol=1e-11,abs_tol=1e-7):raise ValueError((a,b))
def main():
    manifest=read(ROOT/'manifest.json')
    for r in manifest['files']:
        if sha(ROOT/r['path'])!=r['sha256']:raise ValueError('Changed package file: '+r['path'])
    instance=load_instance(ROOT/'input/polyu_case_project_wp_large_934.rcp')
    assert (instance.n_tasks,instance.n_arcs,instance.inactive_count)==(934,1261,236)
    scenarios=read(ROOT/'config/scenarios.json')['scenarios'];checked=[]
    for s in scenarios:
        row=rows(ROOT/s['summary_file'])[s['summary_row_zero_based']]
        partition=tuple(tuple(x) for x in read(ROOT/s['partition_file'])['final_partition_zero_based'])
        assert partition_is_valid(instance,partition),s['scenario_id']
        assert all(len(p)==1 for p in partition if any(instance.tasks[i].inactive for i in p))
        result=evaluate_partition(instance,partition,PolicyParams(**s['parameters']))
        for key in ['subsidy_pv','tax_pv','setup_pv']:close(getattr(result,key),row[key])
        close(result.total_value,row['final_value']);assert len(partition)==int(row['final_packages'])
        history=rows(ROOT/s['history_file'])
        assert int(history[0]['iteration'])==0
        assert all(float(b['total_value'])>float(a['total_value']) for a,b in zip(history,history[1:]))
        close(history[0]['total_value'],row['initial_value']);close(history[-1]['total_value'],row['final_value'])
        checked.append(dict(scenario_id=s['scenario_id'],packages=len(partition),value=result.total_value))
    assert len(checked)==21
    print(json.dumps(dict(status='passed',checked_files=len(manifest['files']),case_tasks=934,arcs=1261,inactive_tasks=236,scenarios_checked=len(checked),optimization_runs=0,results=checked),indent=2))
if __name__=='__main__':main()
